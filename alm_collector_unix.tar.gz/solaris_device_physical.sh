#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_physical_solaris.sh							#
#	Funktion:	Abfrage der Physik unter Solaris						#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	6 (04.11.2018): Falko Boehme (T-DCI-CCDB), falko.boehme@telekom.de				#
#		Neu: Standardwerte aus der user.conf mit aufnehmen					#
#													#
#	5 (16.10.2017): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: Cores + Threads + Mem der wirklichen Physik statt der Control-LDOM bei LDOMs #
#													#
#	4 (07.09.2017): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: Control-LDOM als System auf Physik (keine Virtualisierung)                   #
#                                                                                                       #
#	3 (03.07.2017): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: LDOM Erkennung                       					#
#													#
#	2 (28.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Neu: Schluessel	phys_core_count und phys_thread_count					#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_SOLARIS_DEVICE_PHYSICAL='6'
	
	# Physical ID
	if [ -r $FILE_PHYSICAL_ID ]
	then
		PHYSICAL_ID=`cat $FILE_PHYSICAL_ID`
	else
		if [ -x /usr/sbin/sneep ]
		then
			PHYSICAL_ID=`/usr/sbin/sneep`
		elif [ -x /usr/sbin/ipmitool ]
		then
			PHYSICAL_ID=`/usr/sbin/ipmitool sunoem getval /SYS/product_serial_number 2>/dev/null | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			if [ -z "$PHYSICAL_ID" ]
			then
				PHYSICAL_ID=`/usr/sbin/ipmitool fru | grep "Chassis Serial" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			fi
		fi
		
		# evt noch die HostID anhaengen (fuer M-Server Domains zum unterscheiden)
		if [ -x /usr/bin/showrev ]
		then
			HOSTID=`/usr/bin/showrev | grep Hostid | awk '{print$2}'`
			PHYSICAL_ID=${PHYSICAL_ID}-${HOSTID}
		fi
		
		if [ -n "$PHYSICAL_ID" ]
		then
			echo "$PHYSICAL_ID" > $FILE_PHYSICAL_ID
			chmod 444 $FILE_PHYSICAL_ID
		fi
	fi
	
	# Server Model
	PHYS_SERVER_MODEL=`prtdiag | grep "System Configuration:" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
	
	# Relation
	PHYS_RELATION='1:1 Relation'
	
	# Memory
	PHYS_MEMORY_MB=`prtconf 2>/dev/null | grep Memory | cut -d ':' -f2 | awk '{print $1}'`
	
	# Solaris Zonen
	if [ -x /usr/sbin/zoneadm ]
	then
		if [ `/usr/sbin/zoneadm list | grep -v global | wc -l | sed 's/^[ \t]*//;s/[ \t]*$//'` -ne 0 ]
		then
			PHYS_RELATION='Host for virt. machines'
			PHYS_VIRTUALIZATION="Solaris Zones"
		fi
	fi
	
	# Solaris LDOM
	if [ -x /usr/sbin/ldm ]
	then
		LDOM_LIST=`/usr/sbin/ldm list 2>/dev/null`
		if [ -n "$LDOM_LIST" ]
		then
			LDOM_COUNT=`echo "$LDOM_LIST" | wc -l`
			if [ "$LDOM_COUNT" -gt 2 ]
			then
				PHYS_RELATION='Host for virt. machines'
				PHYS_VIRTUALIZATION="Solaris LDOM"
			fi
		fi
	fi
	
	json_array_get_index_by_module "device_physical"
	
	json_module_start_level "$PHYSICAL_ID"
	json_module_key_value "phys_script_version" "$SCRIPT_VERSION_SOLARIS_DEVICE_PHYSICAL"
	json_module_key_value "phys_script_last_update" "$DATE_TIME"
	json_module_key_value "phys_device_id" "$PHYSICAL_ID"
	json_module_key_value "phys_hostname" "$HOSTNAME"
	json_module_key_value "phys_relation" "$PHYS_RELATION"
	json_module_key_value "phys_os" "$OS_TYPE"
	json_module_key_value "phys_server_model" "$PHYS_SERVER_MODEL"
	json_module_key_value "phys_cpu_model" "$CPU_MODEL"
	json_module_key_value "phys_is_active" "y"
	json_module_key_value "phys_fqdn" "$FQDN"
	json_module_key_value "phys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
	json_module_key_value "phys_operating_legal_entity_name" "$LEGAL_NAME"
	json_module_key_value "phys_operating_legal_entity_number" "$LEGAL_NUMBER"
	json_module_key_value "phys_operating_business_unit_name" "$BUSINESS_UNIT_NAME"
	json_module_key_value "phys_operating_accounting_area" "$ACCOUNTING_AREA"
	json_module_key_value "phys_operating_cost_center" "$COST_CENTER"
	json_module_key_value "phys_installation_country" "$COUNTRY"
	json_module_key_value "phys_installation_city" "$CITY"
	json_module_key_value "phys_installation_street" "$STREET"
	
	if [ "$PHYS_RELATION" = "1:1 Relation" ]
	then
		# Standard, eigene Physik
		json_module_key_value "phys_machine_uuid" "$MACHINE_UUID"
		json_module_key_value "phys_cpu_count" "$CPU_COUNT"
		json_module_key_value "phys_core_count" "$CPU_CORE_COUNT"
	        json_module_key_value "phys_thread_count" "$CPU_THREAD_COUNT"
	        json_module_key_value "phys_memory_mb" "$PHYS_MEMORY_MB"
                json_module_end_level
	fi
	
	if [ "$PHYS_RELATION" = "Host for virt. machines" ]
	then
		case "$PHYS_VIRTUALIZATION" in
		'Solaris Zones')
			json_module_key_value "phys_machine_uuid" "$MACHINE_UUID"
			json_module_key_value "phys_cpu_count" "$CPU_COUNT"
			json_module_key_value "phys_core_count" "$CPU_CORE_COUNT"
	                json_module_key_value "phys_thread_count" "$CPU_THREAD_COUNT"
	                json_module_key_value "phys_memory_mb" "$PHYS_MEMORY_MB"
			;;
		
		'Solaris LDOM')
		        CPU_CORE_COUNT=`ldm ls-devices -a core | grep -c "("`
                        CPU_THREAD_COUNT=`ldm ls-devices -a cpu | tail -2 | head -1 | awk '{print $1}'`
                        CPU_THREAD_COUNT=$((CPU_THREAD_COUNT+1))                        # Da die Threads bei 0 anfangen
                        MB_SEG=$(echo `ldm ls-devices -a mem |awk ' { print $2 } ' |sort -nr |grep -v SIZE |grep M |tr -d M |awk '{sum+=$1}END{print sum}' |sed '/^$/d' ` )
                        GB_SEG=$(echo `ldm ls-devices -a mem |awk ' { print $2 } ' |sort -nr |grep -v SIZE |grep G |tr -d G |awk '{sum+=$1}END{print sum}' |sed '/^$/d' ` )
                        GB_SEG_MB=$(echo "$GB_SEG" "*" "1024" |bc )
                        PHYS_MEMORY_MB=$(echo "$MB_SEG" "+" "$GB_SEG_MB" |bc)
			json_module_key_value "phys_machine_uuid" "$MACHINE_UUID"	# Die Control-Domain wird als System auf Physik gesehen
			#json_module_key_value "phys_cpu_count" "$CPU_COUNT"		# Anzahl der CPUs unbekannt
			json_module_key_value "phys_core_count" "$CPU_CORE_COUNT"
	                json_module_key_value "phys_thread_count" "$CPU_THREAD_COUNT"
	                json_module_key_value "phys_memory_mb" "$PHYS_MEMORY_MB"
			;;
		esac
		
		json_module_end_level
		
		# Virtualisierung aus Physik-Sicht abfragen
		. ./solaris_device_phys_for_virt.sh
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi