#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		cpu_solaris.sh									#
#	Funktion:	Abfrage der CPU unter Solaris							#
#	Version:	0.1										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	2 (28.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Wegfall des Schluessels cpu_has_hyperthreading (aus cpu_threads_per_core ableitbar)     #
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
        SCRIPT_VERSION_SOLARIS_DEVICE_CPU='2'
        
        KSTAT_CPUINFO=`/bin/kstat -m cpu_info`
        TMP_CPU_MODEL=`echo "$KSTAT_CPUINFO" | grep brand | uniq`
        if [ -n "$TMP_CPU_MODEL" ]
        then
                CPU_MODEL=`echo ${TMP_CPU_MODEL#*brand} | head -1`
        else
                CPU_MODEL=`echo "$KSTAT_CPUINFO" | grep implementation | head -1 | awk '{print $2}'`
        fi
        
        CPU_SPEED_MHZ=`echo "$KSTAT_CPUINFO" | grep -i clock_MHz | uniq | awk '{print $2}'`
        if [ -n "$BC_BINARY" ]
        then
                CPU_SPEED_GHZ=`echo "scale=2; $CPU_SPEED_MHZ/1000" | bc`
        fi
        
        CPU_COUNT=`echo "$KSTAT_CPUINFO" | grep chip_id | awk '{print $2}' | sort | uniq | wc -l | tr -d ' '`
        
        CPU_CORE_COUNT=`echo "$KSTAT_CPUINFO" | grep core_id | grep -v pkg_core_id | awk '{print $2}' | sort | uniq | wc -l | tr -d ' '`
        if [ "$CPU_CORE_COUNT" -eq 0 ]
        then
                CPU_CORE_COUNT=`echo "$KSTAT_CPUINFO" | grep chip_id | awk '{print $2}' | sort | uniq | wc -l | tr -d ' '`
        fi
        
        CPU_THREAD_COUNT=`echo "$KSTAT_CPUINFO" | grep "module: cpu_info" | awk '{ print $4 }' | sort | uniq | wc -l | tr -d ' '`
        
        if [ -n "$CPU_COUNT" ] &&[ "$CPU_COUNT" -ge 1 ]
        then
        	CPU_CORES_PER_CPU=$((CPU_CORE_COUNT/CPU_COUNT))
        fi
        
        if [ -n "$CPU_COUNT" ] &&[ "$CPU_COUNT" -ge 1 ]
        then
        	CPU_THREADS_PER_CPU=$((CPU_THREAD_COUNT/CPU_COUNT))
        fi
        
        if [ -n "$CPU_CORE_COUNT" ] &&[ "$CPU_CORE_COUNT" -ge 1 ]
        then
        	CPU_THREADS_PER_CORE=$((CPU_THREAD_COUNT/CPU_CORE_COUNT))
        fi
        
        if [ -z "$VIRTUALIZATION_TECHNOLOGY" ]
        then
        	json_array_get_index_by_module "device_cpu"
        	
        	# eigene CPU ausgeben
        	json_module_start_level "$CPU_MODEL"
        	json_module_key_value "cpu_script_version" "$SCRIPT_VERSION_SOLARIS_DEVICE_CPU"
        	json_module_key_value "cpu_script_last_update" "$DATE_TIME"
        	json_module_key_value "cpu_data_source" "$HOSTNAME"
        	json_module_key_value "cpu_model" "$CPU_MODEL"
        	json_module_key_value "cpu_cores_per_cpu" "$CPU_CORES_PER_CPU"
        	json_module_key_value "cpu_threads_per_cpu" "$CPU_THREADS_PER_CPU"
        	json_module_key_value "cpu_threads_per_core" "$CPU_THREADS_PER_CORE"
        	json_module_key_value "cpu_speed_ghz" "$CPU_SPEED_GHZ"
        	json_module_key_value "cpu_is_active" "y"
        	json_module_end_level
        fi
        
        if [ "$PHYS_VIRTUALIZATION" = "Solaris LDOM" ]
        then
        # wir erfassen ein LDOM_PRIMARY und wollen nicht in Information der Primary, sondern des physikalischen Servers, deshalb Abfrage mit ldm
        	LDM_CORE=`/usr/sbin/ldm ls-devices -a core`
        	if [ $? -eq 0 ]
        	then
        	        CPU_CORE_COUNT=`echo "$LDM_CORE" | grep "(" | wc -l | awk '{print $1}'`
        	        CPU_THREADS_PER_CORE=`echo "$LDM_CORE" | grep "(" | head -1 | cut -d '(' -f2 | awk '{print NF}'`
        	fi
        	
        	json_array_get_index_by_module "device_cpu"
        	
        	json_module_start_level "$CPU_MODEL"
        	json_module_key_value "cpu_script_version" "$SCRIPT_VERSION_DEVICE_CPU_SOLARIS"
        	json_module_key_value "cpu_script_last_update" "$DATE_TIME"
        	json_module_key_value "cpu_data_source" "$HOSTNAME"
        	json_module_key_value "cpu_model" "$CPU_MODEL"
        	#json_module_key_value "cpu_cores_per_cpu" "$CPU_CORES_PER_CPU"		# nicht ermittelbar, da Anzahl an CPUs unbekannt
        	#json_module_key_value "cpu_threads_per_cpu" "$CPU_THREADS_PER_CPU"	# nicht ermittelbar, da Anzahl an CPUs unbekannt
        	json_module_key_value "cpu_threads_per_core" "$CPU_THREADS_PER_CORE"
        	json_module_key_value "cpu_speed_ghz" "$CPU_SPEED_GHZ"
        	json_module_key_value "cpu_is_active" "y"
        	json_module_end_level
        fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi