#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		solaris_device_phys_for_virt.sh 						#
#	Funktion:	Zuordnung der virtuellen Server zu dem physikalischen Server unter Solaris	#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	3 (16.10.2017): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Neu: capped/uncapped und whole-core Konfiguration bei Solaris LDOMs			#
#													#
#	2 (06.04.2017): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: UUID auslesen bei Solaris LDOMs						#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_SOLARIS_DEVICE_PHYS_FOR_VIRT='3'
	
	if [ -n "$PHYS_VIRTUALIZATION" ]
	then
		case $PHYS_VIRTUALIZATION in
			'Solaris Zones')
				json_array_get_index_by_module "device_virtual"
				
				# Globale Zone entfaellt, da es immer eine Globale Zone gibt
				#json_module_start_level "$MACHINE_UUID"
				#json_module_key_value "virt_device_id" "$PHYSICAL_ID"
				#json_module_key_value "virt_machine_uuid" "$MACHINE_UUID"
				#json_module_key_value "virt_hostname" "$HOSTNAME"
				#json_module_key_value "virt_virtualization_tech" "$PHYS_VIRTUALIZATION"
				#json_module_key_value "virt_sun_gzone_id" "global"
				#json_module_key_value "virt_sun_gzone_core_count" "$CPU_CORE_COUNT"
				#json_module_key_value "virt_sun_gzone_virtual_core_count" "$CPU_THREAD_COUNT"
				#json_module_key_value "virt_sun_gzone_is_capped" "uncapped"
				#json_module_key_value "virt_is_active" "y"
				#json_module_key_value "virt_script_last_update" "$DATE_TIME"
				#json_module_end_level
			
				# Lokale Zonen
				ZONE_LIST=`zoneadm list -p | grep -v global`
				for ZONE in $ZONE_LIST
				do
					ZONE_NAME=`echo $ZONE | cut -d ':' -f2`
					ZONE_UUID=`echo $ZONE | cut -d ':' -f5`
					
					# Zone in Virtualisierungsliste (FILE_VIRTUALIZATION_CLIENTS) mit aufnehmen
					push_virt_to_file "$PHYS_VIRTUALIZATION" "$ZONE_NAME" "$ZONE_UUID"
					# evt. vorhandenen Eintrag uebernehmen
					PHYS_VIRTUALIZATION=$VIRT_CLIENT_TECH
					ZONE_UUID=$VIRT_CLIENT_UUID
					
					# Strings mit RegEx ueberpruefen
					UUID_TEST=`echo "$ZONE_UUID" | sed "s/$REGEX_UUID//"`
					if [ -z "$UUID_TEST" ]
					then
						VIRT_CAPPED_UNCAPPED="uncapped"
						
						# Hat die Zone eigene CPUs (Threads) zugeweiesen?
						ZONE_DEDICATED_CPU=`zonecfg -z $ZONE_NAME info dedicated-cpu`
						if [ -n "$ZONE_DEDICATED_CPU" ]
						then
							VIRT_CAPPED_UNCAPPED="capped"
						fi
						
						# Ist ein Pool konfiguriert?
						ZONE_CPU_POOL=`zonecfg -z $ZONE_NAME info | grep pool | cut -d ':' -f2 | awk '{print $1}'`
						if [ -n "$ZONE_CPU_POOL" ]
						then
							# Ist ein pset (Prozessor-Set) in dem Pool?
							POOL_PSET=`poolcfg -c "info pool $ZONE_CPU_POOL" | grep "pset "`
							if [ -n "$POOL_PSET" ]
							then
								# Ist pset.max definiert
								POOL_PSET_MAX=`poolcfg -c "info pool $ZONE_CPU_POOL" | grep pset.max | awk '{print $3}'`
								if [ -n "$POOL_PSET_MAX" ]
								then
									VIRT_SUN_RES_ID="$ZONE_CPU_POOL"
									VIRT_SUN_RES_VIRTUAL_CORE_COUNT="$POOL_PSET_MAX"
									VIRT_SUN_LZONE_VIRTUAL_CORE_COUNT=$VIRT_SUN_RES_VIRTUAL_CORE_COUNT
									
									# Ist pset.max kleiner als die maximale Anzahl an Threads?
									if [ "$POOL_PSET_MAX" -lt "$CPU_THREAD_COUNT" ]
									then
										# Es sind begrenzte Ressource zugeweisen
										VIRT_CAPPED_UNCAPPED="capped"
									else
										# Es sind unbegrenzte Ressource verfuegbar
										# Damit es nicht mehr Threads in dem Pool gibt, als der Server hat
										VIRT_SUN_RES_VIRTUAL_CORE_COUNT=$CPU_THREAD_COUNT
										VIRT_SUN_LZONE_VIRTUAL_CORE_COUNT=$VIRT_SUN_RES_VIRTUAL_CORE_COUNT
									fi
									
									if [ -n "$CPU_THREADS_PER_CORE" ]
									then
										VIRT_SUN_RES_CORE_COUNT=$((VIRT_SUN_RES_VIRTUAL_CORE_COUNT/CPU_THREADS_PER_CORE))
										VIRT_SUN_LZONE_CORE_COUNT=$VIRT_SUN_RES_CORE_COUNT
									fi
								fi
							fi
						fi
						
						# Virtualisierung
						json_array_get_index_by_module "device_virtual"
						
						json_module_start_level "$ZONE_UUID"
						json_module_key_value "virt_device_id" "$PHYSICAL_ID"
						json_module_key_value "virt_machine_uuid" "$ZONE_UUID"
						json_module_key_value "virt_virtualization_tech" "$PHYS_VIRTUALIZATION"
						if [ -n "$VIRT_LEVEL1" ]
						then
							json_module_key_value "virt_2vl_virtualization_tech" "$VIRT_LEVEL1"
							json_module_key_value "virt_2vl_1vl_id" "$MACHINE_UUID"
						fi
						json_module_key_value "virt_sun_lzone_id" "$ZONE_NAME"
						json_module_key_value "virt_sun_lzone_core_count" "$VIRT_SUN_LZONE_CORE_COUNT"
						json_module_key_value "virt_sun_lzone_virtual_core_count" "$VIRT_SUN_LZONE_VIRTUAL_CORE_COUNT"
						json_module_key_value "virt_sun_lzone_is_capped" "$VIRT_CAPPED_UNCAPPED"
						json_module_key_value "virt_sun_res_id" "$VIRT_SUN_RES_ID"
						json_module_key_value "virt_sun_res_core_count" "$VIRT_SUN_RES_CORE_COUNT"
						json_module_key_value "virt_sun_res_virtual_core_count" "$VIRT_SUN_RES_VIRTUAL_CORE_COUNT"
						json_module_key_value "virt_is_active" "y"
						json_module_key_value "virt_script_last_update" "$DATE_TIME"
						json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
						json_module_end_level
						
						# System
						json_array_get_index_by_module "device_system"
						json_module_start_level "$ZONE_UUID"
						json_module_key_value "sys_machine_uuid" "$ZONE_UUID"
						json_module_key_value "sys_script_last_update" "$DATE_TIME"
						json_module_key_value "sys_is_active" "y"
						json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
						json_module_end_level
					fi
				done
				;;
			
			'Solaris LDOM')
				LDOM_LIST=`ldm list | grep -v "FLAGS" | cut -d" " -f1`
				for LDOM in $LDOM_LIST
				do
					# Nur Gast-LDOMs aufnehmen
					if [ "$LDOM" != "primary" ]
					then
						LDOM_NAME=$LDOM
						LDOM_UUID=`ldm list -l -p $LDOM | grep "uuid=" | cut -d "=" -f2`
						
						if [ -z "$LDOM_UUID" ]
						then
							# UUID selber generieren
							gen_uuid
							if [ -n "$UUID" ]
							then
								LDOM_UUID=$UUID
							else
								echo "LDOM has no UUID and no possibility found to generate an UUID."
								echo "Please add virtualization to $FILE_VIRTUALIZATION_CLIENTS manually."
								echo "Aborting"
								script_stop 2
							fi
						fi
						# Strings mit RegEx ueberpruefen
						UUID_TEST=`echo "$LDOM_UUID" | sed "s/$REGEX_UUID//"`
						if [ -z "$UUID_TEST" ]
						then
							# Zone in Virtualisierungsliste (FILE_VIRTUALIZATION_CLIENTS) mit aufnehmen
							push_virt_to_file "$PHYS_VIRTUALIZATION" "$LDOM_NAME" "$LDOM_UUID"
							# evt. vorhandenen Eintrag uebernehmen
							PHYS_VIRTUALIZATION=$VIRT_CLIENT_TECH
							LDOM_UUID=$VIRT_CLIENT_UUID
							
							# capped / uncapped + dedicated whole-core
                                                        LDOM_RESMGMT=`ldm list -o resmgmt $LDOM`
                                                        LDOM_MAX_CORES=`echo "$LDOM_RESMGMT" | grep max-cores`
                                                        LDOM_WHOLE_CORE_TMP=`echo "$LDOM_RESMGMT" | grep "cpu=whole-core"`
                                                        if [ -z "$LDOM_MAX_CORES" ]
                                                        then
                                                                LDOM_CAPPED_UNCAPPED="uncapped"
                                                        else
                                                                LDOM_CAPPED_UNCAPPED="capped"
                                                        fi
                                                        if [ -z "$LDOM_WHOLE_CORE_TMP" ]
                                                        then
                                                                LDOM_WHOLE_CORE="n"
                                                        else
                                                                LDOM_WHOLE_CORE="y"
                                                        fi
                                                        
							# Virtualisierung
							json_array_get_index_by_module "device_virtual"
								
							json_module_start_level "$LDOM_UUID"
							json_module_key_value "virt_device_id" "$PHYSICAL_ID"
							json_module_key_value "virt_machine_uuid" "$LDOM_UUID"
							json_module_key_value "virt_virtualization_tech" "$PHYS_VIRTUALIZATION"
							json_module_key_value "virt_sun_ldom_id" "$LDOM_NAME"
							json_module_key_value "virt_is_active" "y"
							json_module_key_value "virt_script_last_update" "$DATE_TIME"
							json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
							json_module_key_value "virt_sun_ldom_is_capped" "$LDOM_CAPPED_UNCAPPED"
                                                        json_module_key_value "virt_sun_ldom_is_dedicated_whole_core" "$LDOM_WHOLE_CORE"
							json_module_end_level
							
							# System
							json_array_get_index_by_module "device_system"
							json_module_start_level "$LDOM_UUID"
							json_module_key_value "sys_machine_uuid" "$LDOM_UUID"
							json_module_key_value "sys_script_last_update" "$DATE_TIME"
							json_module_key_value "sys_is_active" "y"
							json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
							json_module_end_level
						fi
					fi
				done
				;;
		esac
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi