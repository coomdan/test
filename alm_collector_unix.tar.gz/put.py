#!/usr/bin/env python
import os
import sys
import httplib
import re


# Configuration
regexp = '^(.*)://(.*?)(/.*)$'
user_agent = 'put.py'

# check for given file
if len(sys.argv) == 3 and os.path.isfile(sys.argv[1]):
    filename = sys.argv[1]
    regres = re.search(regexp, sys.argv[2])
    if not regres:
        print('Please enter a valid URL in the format http(s)://IP/PATH-to-API')
        sys.exit(1)
    else:
        alm_protocol = regres.group(1)
        alm_server = regres.group(2)
        alm_uri = regres.group(3)
else:
    print('Please enter a valid filename and the full URI of the API')
    sys.exit(1)

# complicated opening because < 2.5 there is no with statement
filehandle = None
try:
    try:
        filehandle = open(filename, 'r')
        filecontent = filehandle.read()
    except:
        print('Error while reading the file')
        sys.exit(1)
finally:
    if filehandle is not None:
       filehandle.close()

# Open connection
if alm_protocol == 'https':
    conn = httplib.HTTPSConnection(regres.group(2), 443)
else:
    conn = httplib.HTTPConnection(regres.group(2), 80)
# Send request
print('Query:\t'+alm_protocol+'://'+alm_server+alm_uri)
try:
    conn.request('PUT', alm_uri, filecontent, {'User-Agent':user_agent})
    response = conn.getresponse()
    print('Status:\t' + str(response.status))
    print('Reason:\t' + response.reason)
    print('Answer:\t' + response.read())
except:
    print('Error while uploading file')
    sys.exit(1)
   
print('Please consider to install curl, to use the official and supported way to upload data to ALM')