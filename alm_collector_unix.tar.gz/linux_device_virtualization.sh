#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_virtualization_linux.sh							#
#	Funktion:	Abfrage der Virtualisierung unter Linux						#
#	Version:	1										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#       2 (23.05.2018): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Neu: Xen Virtualisierung								#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_LINUX_DEVICE_VIRTUALIZATION='2'
			
	if [ -n "$VIRTUALIZATION_TECHNOLOGY" ]
	then
	        MEMORY_KB=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
        	MEMORY_MB=$((MEMORY_KB/1024))
	        
		json_array_get_index_by_module "device_virtual"
		
		json_module_start_level "$MACHINE_UUID"
		json_module_key_value "virt_machine_uuid" "$MACHINE_UUID"
		json_module_key_value "virt_hostname" "$HOSTNAME"
		json_module_key_value "virt_virtualization_tech" "$VIRTUALIZATION_TECHNOLOGY"
		json_module_key_value "virt_is_active" "y"
		json_module_key_value "virt_script_version" "$SCRIPT_VERSION_LINUX_DEVICE_VIRTUALIZATION"
		json_module_key_value "virt_script_last_update" "$DATE_TIME"
		json_module_key_value "virt_memory_mb" "$MEMORY_MB"
		json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
		
		case "$VIRTUALIZATION_TECHNOLOGY" in
			'VMware')
				json_module_key_value "virt_vmware_core_count" "$CPU_CORE_COUNT"
				;;
			'VirtualBox')
				json_module_key_value "virt_other_1vl_core_count" "$CPU_CORE_COUNT"
				json_module_key_value "virt_other_1vl_virtual_core_count" "$CPU_THREAD_COUNT"
				;;
			'KVM')
			        json_module_key_value "virt_other_1vl_core_count" "$CPU_CORE_COUNT"
				json_module_key_value "virt_other_1vl_virtual_core_count" "$CPU_THREAD_COUNT"
				;;
			'Xen')
			        #json_module_key_value "virt_other_1vl_core_count" "$CPU_CORE_COUNT"
				json_module_key_value "virt_other_1vl_virtual_core_count" "$CPU_THREAD_COUNT"
				;;
		esac
		json_module_end_level
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi