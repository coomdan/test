#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_phys_for_virt_linux.sh							#
#	Funktion:	Zuordnung der virtuellen Server zu dem physikalischen Server unter Linux	#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	7 (23.05.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Xen Threads auslesen                                        			#
#													#
#	6 (02.02.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Xen Virtualisierung mit xm                                 			#
#													#
#	5 (14.12.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Korrektur: Control domain VMs bei Xen-Virtualisierung ausblenden			#
#													#
#	4 (21.11.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Erkennung von KVM									#
#													#
#	3 (03.11.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Korrektur: Transfer VMs bei Xen-Virtualisierung (Citrix) ausblenden			#
#													#
#	2 (01.09.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Abfrage von Xen-Virtualisierung (Citrix)						#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_LINUX_DEVICE_PHYS_FOR_VIRT='7'
	
	if [ -n "$PHYS_VIRTUALIZATION" ]
	then
		case $PHYS_VIRTUALIZATION in
			"VirtualBox")
				VIRTUALBOX_LIST=`ps -ef | grep VirtualBox | grep "startvm "`
				for STRING in $VIRTUALBOX_LIST
				do
					# Strings mit RegEx ueberpruefen
					UUID_TEST=`echo "$STRING" | sed "s/$REGEX_UUID//"`
					if [ -z "$UUID_TEST" ]
					then
						VIRT_MACHINE_UUID=$STRING
						
						# Virtualisierung
						json_array_get_index_by_module "device_virtual"
						
						json_module_start_level "$VIRT_MACHINE_UUID"
						json_module_key_value "virt_device_id" "$PHYSICAL_ID"
						json_module_key_value "virt_machine_uuid" "$VIRT_MACHINE_UUID"
						json_module_key_value "virt_virtualization_tech" "$PHYS_VIRTUALIZATION"
						json_module_key_value "virt_is_active" "y"
						json_module_key_value "virt_script_last_update" "$DATE_TIME"
						json_module_key_value "virt_other_1vl_id" "$VIRT_MACHINE_UUID"
						json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
						json_module_end_level
						
						# System
						json_array_get_index_by_module "device_system"
						json_module_start_level "$VIRT_MACHINE_UUID"
						json_module_key_value "sys_machine_uuid" "$VIRT_MACHINE_UUID"
						json_module_key_value "sys_script_last_update" "$DATE_TIME"
						json_module_key_value "sys_is_active" "y"
						json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
						json_module_end_level
					fi
				done
				;;
			"Xen")
				# Unterscheidung zwischen xen und xe (Citrix)
				if [ -n "$XE_VMLIST" ] 
				then
					UUID_LIST=`echo "$XE_VMLIST" | grep -i uuid`
					STATE_LIST=`echo "$XE_VMLIST" | grep -i power-state`
					NAME_LIST=`echo "$XE_VMLIST" | grep -i name-label`
					IFS=$'\n'
					XE_UUID_INDEX=0
					for LINE in $UUID_LIST
					do
						XE_UUID_LIST_ARRAY[$XE_UUID_INDEX]=`echo $LINE | cut -d ':' -f2 | sed 's/^[ \t\r]*//;s/[ \t\r]*$//'`
						XE_UUID_INDEX=$((XE_UUID_INDEX+1))
					done
					XE_STATE_INDEX=0
					for LINE in $STATE_LIST
					do
						XE_STATE_LIST_ARRAY[$XE_STATE_INDEX]=`echo $LINE | cut -d ':' -f2 | sed 's/^[ \t\r]*//;s/[ \t\r]*$//'`
						XE_STATE_INDEX=$((XE_STATE_INDEX+1))
					done
					XE_NAME_INDEX=0
					for LINE in $NAME_LIST
					do
						XE_NAME_LIST_ARRAY[$XE_NAME_INDEX]=`echo $LINE | cut -d ':' -f2 | sed 's/^[ \t\r]*//;s/[ \t\r]*$//'`
						XE_NAME_INDEX=$((XE_NAME_INDEX+1))
					done
					
					# Auswertung
					XE_INDEX=0
					for LINE in ${XE_STATE_LIST_ARRAY[@]}
					do
						DUMMY=`echo "$LINE" | grep running`
						if [ $? -eq 0 ]
						then
							XE_UUID=${XE_UUID_LIST_ARRAY[$XE_INDEX]}
							XE_NAME=${XE_NAME_LIST_ARRAY[$XE_INDEX]}
							
						        # Transfer VMs werden nicht benoetigt und werden ausgeblendet
							SKIP_VM="false"
							DUMMY=`echo $XE_NAME | grep "Transfer VM for VDI"`
							if [ $? -eq 0 ]
							then
								SKIP_VM="true"
							fi
							DUMMY=`echo $XE_NAME | grep "Control domain on host"`
							if [ $? -eq 0 ]
							then
									SKIP_VM="true"
							fi
							if [ "$SKIP_VM" = "false" ]
							then
							       	# Zone in Virtualisierungsliste (FILE_VIRTUALIZATION_CLIENTS) mit aufnehmen
								push_virt_to_file "$PHYS_VIRTUALIZATION" "$XE_NAME" "$XE_UUID"
								
								# Virtualisierung
								json_array_get_index_by_module "device_virtual"
								json_module_start_level "$XE_UUID"
								json_module_key_value "virt_device_id" "$PHYSICAL_ID"
								json_module_key_value "virt_machine_uuid" "$XE_UUID"
								json_module_key_value "virt_virtualization_tech" "$PHYS_VIRTUALIZATION"
								json_module_key_value "virt_is_active" "y"
								json_module_key_value "virt_script_last_update" "$DATE_TIME"
								json_module_key_value "virt_other_1vl_id" "$XE_NAME"
								json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
								json_module_end_level
								
								# System
								json_array_get_index_by_module "device_system"
								json_module_start_level "$XE_UUID"
								json_module_key_value "sys_machine_uuid" "$XE_UUID"
								json_module_key_value "sys_script_last_update" "$DATE_TIME"
								json_module_key_value "sys_is_active" "y"
								json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
								json_module_end_level
							fi
						fi
						XE_INDEX=$((XE_INDEX+1))
					done
				fi
				
				# Xen mit xm
				if [ -n "$XM_VMLIST" ]
				then
					IFS=$'\n'
					for LINE in $XM_VMLIST
					do
						SKIP_VM="false"
						XM_NAME=`echo "$LINE" | awk '{print $1}'`
						if [ "$XM_NAME" = "Name" ] || [ "$XM_NAME" = "Domain-0" ]
						then
							SKIP_VM="true"
						fi
						if [ "$SKIP_VM" = false ]
						then
							XM_LIST_LONG=`/usr/sbin/xm list $XM_NAME -l`
							XM_UUID=`echo "$XM_LIST_LONG" | grep uuid | head -1 | awk '{print $2}' | cut -d ')' -f1`
							XM_THREADS=`echo "$XM_LIST_LONG" | grep online_vcpus | head -1 | awk '{print $2}' | cut -d ')' -f1`
                                                        
							# Zone in Virtualisierungsliste (FILE_VIRTUALIZATION_CLIENTS) mit aufnehmen
						        push_virt_to_file "$PHYS_VIRTUALIZATION" "$XM_NAME" "$XM_UUID"
                                                        
                                                        # Cores berechnen aus Threads, ceil falls es Nachkommastellen gibt
                                                        XM_CORES_TMP=`awk "BEGIN {print $XM_THREADS/$CPU_THREADS_PER_CORE}"`
                                                        ceil $XM_CORES_TMP
                                                        XM_CORES=$CEIL_RESULT
                                                        
							# Virtualisierung
							json_array_get_index_by_module "device_virtual"
							json_module_start_level "$XM_UUID"
							json_module_key_value "virt_device_id" "$PHYSICAL_ID"
							json_module_key_value "virt_machine_uuid" "$XM_UUID"
							json_module_key_value "virt_virtualization_tech" "$PHYS_VIRTUALIZATION"
							json_module_key_value "virt_is_active" "y"
							json_module_key_value "virt_script_last_update" "$DATE_TIME"
							json_module_key_value "virt_other_1vl_id" "$XM_NAME"
							json_module_key_value "virt_other_1vl_virtual_core_count" "$XM_THREADS"
					                json_module_key_value "virt_other_1vl_core_count" "$XM_CORES"
							json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
							json_module_end_level

							# System
							json_array_get_index_by_module "device_system"
							json_module_start_level "$XM_UUID"
							json_module_key_value "sys_machine_uuid" "$XM_UUID"
							json_module_key_value "sys_script_last_update" "$DATE_TIME"
							json_module_key_value "sys_is_active" "y"
							json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
							json_module_end_level
						fi
					done
				fi
				;;
			
			"KVM")
				if [ -x /bin/virsh ]
				then
					VIRSH_NAME_LIST=`/bin/virsh list --name`
					for VIRSH_NAME in $VIRSH_NAME_LIST
					do
						VIRSH_NAME_INFO=`/bin/virsh dominfo $VIRSH_NAME`
						VIRSH_UUID=`echo "$VIRSH_NAME_INFO" | grep UUID | awk '{print $2}'`
						VIRSH_THREAD_COUNT=`echo "$VIRSH_NAME_INFO" | grep "CPU(s)" | awk '{print $2}'`
						# Memory nicht auswerten, das macht das Skript innerhalb der VM
						#VIRSH_MEMORY_KB=`echo "$VIRSH_NAME_INFO" | grep "Max memory" | cut -d ':' -f2 | awk '{print $1}'`
						#VIRSH_MEMORY_MB=$((VIRSH_MEMORY_KB/1024))
						VIRT_MACHINE_UUID=$VIRSH_UUID
						
						# Virtualisierung
						json_array_get_index_by_module "device_virtual"
						
						json_module_start_level "$VIRT_MACHINE_UUID"
						json_module_key_value "virt_device_id" "$PHYSICAL_ID"
						json_module_key_value "virt_machine_uuid" "$VIRT_MACHINE_UUID"
						json_module_key_value "virt_virtualization_tech" "$PHYS_VIRTUALIZATION"
						json_module_key_value "virt_is_active" "y"
						json_module_key_value "virt_script_last_update" "$DATE_TIME"
						json_module_key_value "virt_other_1vl_id" "$VIRSH_NAME"
						json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
						#json_module_key_value "virt_memory_mb" $VIRSH_MEMORY_MB
						json_module_key_value "virt_other_1vl_virtual_core_count" "$VIRSH_THREAD_COUNT"
						json_module_end_level
						
						# System
						json_array_get_index_by_module "device_system"
						json_module_start_level "$VIRT_MACHINE_UUID"
						json_module_key_value "sys_machine_uuid" "$VIRT_MACHINE_UUID"
						json_module_key_value "sys_script_last_update" "$DATE_TIME"
						json_module_key_value "sys_is_active" "y"
						json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
						json_module_end_level
					done
				fi
				;;
		esac
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi