-- ######################################################################################################
-- #													#
-- #	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
-- #	Skript:		server_database_oracle_basics.sql						#
-- #	Funktion:	SQL-Abfrage von Oracle Datenbanken (Basis-Daten)				#
-- #													#
-- ######################################################################################################
-- #													#
-- #	Versionshistorie:										#
-- #													#
-- #	2 (17.01.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: Auslesen von Version abhaengig						#
-- #									        			#
-- #	1 (01.06.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Erste Version										#
-- #													#
-- ######################################################################################################



-- ################
-- # Formatierung #
-- ################
set heading off;
set feedback off;
set lines 2000;
set pages 100;
alter session set NLS_DATE_FORMAT='YYYY-MM-DD HH24:Mi:ss';
set serveroutput on


declare
        eTableNotExists exception;
	eColumnNotExists exception;
	pragma exception_init(eTableNotExists, -00942);
	pragma exception_init(eColumnNotExists, -00904);
	type result_table is table of varchar2(1024) index by varchar2(128);

	seperator constant varchar2(1) := '|';
	result result_table;
	result_idx varchar2(128);
	pos_release number;
	oracle_main_version varchar2(5);
	oracle_major_version varchar2(5);
	oracle_version varchar2(10);
	sql_query varchar2(1024);

	
begin
-- ################################
-- # Werte fuer spaetere Abfragen #
-- ################################
	select substr(version, 1, instr(version, '.')-1) into oracle_main_version from v$instance;
	select substr(version, 1, instr(version, '.', 1, 2)-1) into oracle_major_version from v$instance;
	select substr(version, 1, instr(version, '.', 1, 4)-1) into oracle_version from v$instance;
	
	
	
-- ##########
-- # Basics #
-- ##########
	select instance_name into result('srv_oracle_instance_name') from v$instance;
	select name into result('srv_oracle_db_name') from v$database;
	select db_unique_name into result('srv_oracle_db_unique_name') from v$database;
	select dbid into result('srv_oracle_db_id') from v$database;
	select version into result('srv_oracle_version') from v$instance;
	select created into result('srv_oracle_db_created') from v$database;
	
	if oracle_main_version > 11 then
        	begin
        		sql_query := 'select cpu_socket_count_highwater from v$license';
        		execute immediate sql_query into result('srv_oracle_cpu_socket_count_highwater');
        		exception when eColumnNotExists then result('srv_oracle_cpu_socket_count_highwater') := '';
        	end;
        	
        	begin
        		sql_query := 'select cpu_count_highwater from v$license';
        		execute immediate sql_query into result('srv_oracle_cpu_count_highwater');
        		exception when eColumnNotExists then result('srv_oracle_cpu_count_highwater') := '';
        	end;
        	
        	begin
        		sql_query := 'select cpu_core_count_highwater from v$license';
        		execute immediate sql_query into result('srv_oracle_core_count_highwater');
        		exception when eColumnNotExists then result('srv_oracle_core_count_highwater') := '';
        	end;
        end if;

        select instr(banner, ' Release') into pos_release from v$version where banner like '%racle%';
        select substr(banner, 0, pos_release-1) into result('srv_oracle_product') from v$version where banner like '%racle%';
        

-- ###########
-- # Ausgabe #
-- ###########
        dbms_output.put_line('dummy empty line');       -- Leerzeile am Anfang, damit der grep ^srv_oracle nicht eine Zeile verschluckt
	result_idx := result.first;
	while (result_idx is not null)
	loop
		dbms_output.put_line(result_idx||seperator||result(result_idx));
		result_idx := result.next(result_idx);
	end loop;
end;
/
quit;