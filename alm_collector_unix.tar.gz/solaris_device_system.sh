#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_system_solaris.sh							#
#	Funktion:	Abfrage des Systems unter Solaris						#
#	Version:	1										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	2 (04.11.2018): Falko Boehme (T-DCI-CCDB), falko.boehme@telekom.de				#
#		Neu: Standardwerte aus der user.conf mit aufnehmen					#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_SOLARIS_DEVICE_SYSTEM='2'
	
	case "$OS_VERSION" in
		'5.10')
			OS_SUBVERSION=`cat /etc/release | grep Solaris | awk '{print $4" "$5}'`
			;;
		'5.11')
			OS_SUBVERSION=`pkg info entire | grep Branch | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			;;
	esac
	
	
	json_array_get_index_by_module "device_system"
	
	json_module_start_level "$MACHINE_UUID"
	json_module_key_value "sys_script_version" "$SCRIPT_VERSION_SOLARIS_DEVICE_SYSTEM"
	json_module_key_value "sys_script_last_update" "$DATE_TIME"
	json_module_key_value "sys_hostname" "$HOSTNAME"
	json_module_key_value "sys_machine_uuid" "$MACHINE_UUID"
	json_module_key_value "sys_is_active" "y"
	json_module_key_value "sys_fqdn" "$FQDN"
	json_module_key_value "sys_os_type" "$OS_TYPE"
	json_module_key_value "sys_os_name" "$OS_NAME"
	json_module_key_value "sys_os_version" "$OS_VERSION"
	json_module_key_value "sys_os_subversion" "$OS_SUBVERSION"
	json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
	json_module_key_value "sys_installation_legal_entity_name" "$LEGAL_NAME"
	json_module_key_value "sys_installation_legal_entity_number" "$LEGAL_NUMBER"
	json_module_key_value "sys_installation_business_unit_name" "$BUSINESS_UNIT_NAME"
	json_module_key_value "sys_installation_accounting_area" "$ACCOUNTING_AREA"
	json_module_key_value "sys_installation_cost_center" "$COST_CENTER"
	json_module_key_value "sys_environment" "$ENVIRONMENT"
	json_module_end_level
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi