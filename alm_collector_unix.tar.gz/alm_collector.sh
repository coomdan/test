#!/usr/bin/env bash
#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		alm_collector.sh								#
#	Funktion:	Abfrage von technischen Parametern, die fuer CLIMA relevant sind:		#
#				- Device CPU								#
#				- Device physikalisch 							#
#				- Device virtuell							#
#				- Device system								#
#			Zusaetzliche Komponenten:							#
#				- SUN Server								#
#				- Microsoft Server (separates Windows Skript)				#
#				- VMware Server								#
#				- Oracle Server								#
#				- Java Server								#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	12 (04.11.2019): Falko Boehme (T-DCI-CCDB), falko.boehme@telekom.de				#
#	        Neu: Anpassungen an user.conf und Abweisen von Daten ohne Gruppe                       	#
#													#
#	11 (07.02.2019): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Neu: Detektion von JAVA				                                      	#
#													#
#	10 (02.02.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Neu: Detektion einer Xen Virtualisierung                                         	#
#													#
#	9 (23.11.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: Abfrage der Physik für AIX-Server durch HMC                                 	#
#													#
#	8 (13.10.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: IBM PowerVM durch LPAR ersetzen                                          	#
#													#
#	7 (07.07.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Korrektur: Detekton Virtualisierung; LDOM vor Zonen erfassen                    	#
#													#
#	6 (03.07.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Korrektur: Erfassung der LDOMs, Primary LDOM ist keine Virtualisierung                	#
#													#
#	5 (06.04.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Korrektur: Erfassung der Gast-DOMs mit Hilfe von virtinfo                         	#
#													#
#	4 (16.11.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Konfiguration der verantwortlichen Gruppe ueber alm.conf.in_use moeglich          	#
#													#
#	3 (06.06.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Erfassung von Oracle Datenbanken                                           	#
#													#
#	2 (10.05.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Speicherung der Virtualisierungsinformationen (UUID) in einer Datei        	#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################


SCRIPT_VERSION_ALM_COLLECTOR='12'

# Initialisierung
WORK_DIR=`dirname $0`
if [ "$WORK_DIR" = "." ]
then
        WORK_DIR=`pwd`
fi
cd $WORK_DIR

if [ -r "./user.conf" ]
then
        . ./user.conf
fi
. ./.alm_environment.conf
. ./alm.conf


if [ -n "$OUTPUT_DIR" ]
then
        ALM_OUTPUT_DIR=$OUTPUT_DIR
fi
if [ -z "$RESPONSIBLE_GROUP_NAME" ]
then
        #RESPONSIBLE_GROUP_NAME=""
	echo "RESPONSIBLE_GROUP_NAME not set in user.conf"
	echo "Aborting ..."
	rm -f $LOCK_FILE 2>&1 > /dev/null
	exit 1
fi
if [ -z "$DESTINATION_IP" ]
then
        DESTINATION_IP="10.90.122.83"
fi
UUID_URL="https://$DESTINATION_IP/$ALM_ENV/uuid"

# Funktionen laden und los geht es!
. ./functions.sh
script_start
check_for_prohibited_keywords

if [ -z "$1" ]
then
	OUTPUT_TO_STDOUT=0
else
	OUTPUT_TO_STDOUT=1
fi

IS_STARTED_FROM_COLLECTOR="true"

DATE=`date '+%Y-%m-%d'`
DATE_TIME=`date '+%Y-%m-%d %H:%M:%S'`
OS_TYPE=`uname`

# Wurde das Skript als root gestartet?
#if [ `who am i | awk '{print $1}'` != 'root' ]
DUMMY=`id | grep "uid=0(root)"`
if [ $? -ne 0 ]
then
	echo 'Script must be run as root. Aborting.'
	script_stop 1
fi

case "$OS_TYPE" in
Linux)
	HOSTNAME=`hostname | cut -d '.' -f1`
	DOMAINNAME=`domainname`
	if [ -z "$DOMAINNAME" ]
	then
		FQDN=$HOSTNAME
	else
		FQDN=$HOSTNAME.$DOMAINNAME
	fi
	
	# Virtualisierung abfragen
	if [ -d /proc/ide/ide0 ]
	then
		DUMMY=`grep -i VMware /proc/ide/ide*/model`
		if [ $? -eq 0 ]
		then
			VIRTUALIZATION_TECHNOLOGY='VMware'
		fi
	fi
	if [ -r /sys/class/dmi/id/product_name ]
	then
	        DUMMY=`grep -i VMware /sys/class/dmi/id/product_name`
	        if [ $? -eq 0 ]
		then
			VIRTUALIZATION_TECHNOLOGY='VMware'
		fi
	fi
	if [ -r /proc/scsi/scsi ]
	then
		DUMMY=`grep -i VMware /proc/scsi/scsi`
		if [ $? -eq 0 ]
		then
			VIRTUALIZATION_TECHNOLOGY='VMware'
		fi
	fi
	if [ -r /sys/devices/virtual/dmi/id/product_name ]
	then
	        VIRTUALBOX_PRODUCT_NAME=`cat /sys/devices/virtual/dmi/id/product_name`
		if [ "$VIRTUALBOX_PRODUCT_NAME" = 'VirtualBox' ]
		then
			VIRTUALIZATION_TECHNOLOGY='VirtualBox'
		fi
	fi
	if [ -x /bin/dmesg ]
	then
		DUMMY=`/bin/dmesg | grep "kvm-clock"`
		if [ $? -eq 0 ]
		then
			VIRTUALIZATION_TECHNOLOGY='KVM'
		fi
	fi
        if [ -x /usr/sbin/dmidecode ]
        then
                DUMMY=`/usr/sbin/dmidecode -s bios-vendor | grep "Xen"`
                if [ $? -eq 0 ]
                then
                        VIRTUALIZATION_TECHNOLOGY='Xen'
                fi
        fi
	
	# UUID laden
	get_machine_uuid
	
	# CPU
	. ./linux_device_cpu.sh
	
	# System
	. ./linux_device_system.sh
	
	if [ -z "$VIRTUALIZATION_TECHNOLOGY" ]
	then
		# Physik
		. ./linux_device_physical.sh
	else 
		# Virtualisierung
		. ./linux_device_virtualization.sh
	fi
	;;
	
	
SunOS)
	HOSTNAME=`hostname | cut -d '.' -f1`
	DOMAINNAME=`domainname`
	if [ -z "$DOMAINNAME" ]
	then
		FQDN=$HOSTNAME
	else
		FQDN=$HOSTNAME.$DOMAINNAME
	fi
	OS_VERSION=`uname -r`
	OS_NAME=`uname -p`
	
	# Virtualisierung ueberpruefen (LDOMs vor Zonen erfassen)
	# VIRTINFO=`/usr/sbin/virtinfo`
	
	# Achtung: ldm kann auch in Zonen installiert sein, daher ist es nicht sehr aussagekraeftig
	if [ -x /usr/sbin/ldm ]
	then
		DUMMY=`/usr/sbin/ldm 2> /dev/null`
		if [ "$?" -eq 0 ]
		then
		        LDOM_IS_CONTROL_DOMAIN="true"
		        # Keine Virtualisierung, das gilt als Physik
		else
		        LDOM_IS_CONTROL_DOMAIN="false"
		        VIRTUALIZATION_TECHNOLOGY='Solaris LDOM'
		fi
	fi
	
	# Wenn ein Zonename != global geliefert wird, ist es sicher eine Zone
	if [ -x /usr/bin/zonename ]
	then
		ZONENAME=`/usr/bin/zonename`
		if [ "$ZONENAME" != "global" ]
		then
			VIRTUALIZATION_TECHNOLOGY='Solaris Zones'
		fi
	fi
	if [ -x /sbin/zonename ]
	then
		ZONENAME=`/sbin/zonename`
		if [ "$ZONENAME" != "global" ]
		then
			VIRTUALIZATION_TECHNOLOGY='Solaris Zones'
		fi
	fi
	
	if [ -x /usr/sbin/smbios ]
	then
		SMBIOS_VERSION_STRING=`/usr/sbin/smbios 2>/dev/null | grep "Version String:" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		if [ "$SMBIOS_VERSION_STRING" = "VirtualBox" ]
		then
			VIRTUALIZATION_TECHNOLOGY='VirtualBox'
		fi
	fi
	
	# UUID laden
	get_machine_uuid
	
	# CPU
	. ./solaris_device_cpu.sh
	
	# System
	. ./solaris_device_system.sh
	
	if [ -z "$VIRTUALIZATION_TECHNOLOGY" ]
	then
		# Physik
		. ./solaris_device_physical.sh
	else 
		# Virtualisierung
		. ./solaris_device_virtualization.sh
	fi
	;;

	
AIX)
	HOSTNAME=`hostname | cut -d '.' -f1`
        #DOMAINNAME=`domainname`
	DOMAINNAME=`grep domain  /etc/resolv.conf | awk '{ print $2 }'`
	if [ -z "$DOMAINNAME" ]
	then
		FQDN=$HOSTNAME
	else
		FQDN=$HOSTNAME.$DOMAINNAME
	fi
	
	# Hardware über HMC für alle Server abfragen
	# läuft nur auf nim184
	if [[ -r /etc/alm/aix_device_hmc.sh && -r ${DIR_ASSET}/hmc_serial_number.txt ]]
	then
		. ./aix_device_hmc.sh
	fi
	
	
	
	DUMMY1=`lsdev | grep vio0`
	
	if [ $? -eq 0 ]
	then
		LPAR_VIRT='VIO'
	fi
	
	LPAR_TYP=`lparstat -i | grep Type | awk -F":" '{ print$2 }' | awk -F"-" '{ print$1 }'`
	
	if [[ $LPAR_VIRT == 'VIO' && $LPAR_TYP != ' Dedicated' ]]
	then
		VIRTUALIZATION_TECHNOLOGY='LPAR'
	fi	

	# UUID laden
	get_machine_uuid
		
	# CPU
	# . ./aix_device_cpu.sh
	
	# System
	. ./aix_device_system.sh
	
	if [ -z "$VIRTUALIZATION_TECHNOLOGY" ]
	then
		# Physik
		. ./aix_device_cpu.sh
		. ./aix_device_physical.sh
	else 
		# Virtualisierung
		. ./aix_device_virtualization.sh
	fi
	;;
esac


#################################################
#						#
#   Ueberpruefen auf zusaetzliche Komponenten	#
#						#
#################################################
# Sun Server
if [ "$OS_TYPE" = "SunOS" ]
then
	. ./server_solaris.sh
fi


# Oracle Database
ORATAB_LIST="/etc/oratab /var/opt/oracle/oratab"
for ORATAB in $ORATAB_LIST
do
	if [ -f "$ORATAB" ]
	then
		ORACLE_ORATAB=$ORATAB
	fi
done

if [ "$OS_TYPE" = "SunOS" ]
then
        if [ "$OS_VERSION" = "5.9" ]
        then
                ORACLE_PMON_LIST=`ps -ef | grep _pmon_ | grep -v grep`
        else
                # Die Zonennamen nicht abschneiden
                ORACLE_PMON_LIST=`ps -eo zone,user,pid,ppid,c,stime,tty,time,comm | grep _pmon_ | grep -v grep | grep $ZONENAME`
                #ORACLE_PMON_LIST=`ps -efZ | grep _pmon_ | grep -v grep | grep $ZONENAME`
                ORACLE_PMON_LIST_WITH_ZONES=1
        fi
else
        ORACLE_PMON_LIST=`ps -ef | grep _pmon_ | grep -v grep`
fi
if [ -n "$ORACLE_PMON_LIST" ] || [ -n "$ORACLE_ORATAB" ]
then
	# Oracle Datenbank
	. ./server_database_oracle.sh
fi


# Java
JAVA_INDEX=1
# Java Binary suchen
for JAVA_BINARY_PATH in `find / -type f -name 'java' 2>/dev/null`
do
	JAVA_BINARY_PATH_ARRAY[$JAVA_INDEX]=$JAVA_BINARY_PATH
	JAVA_INDEX=$((JAVA_INDEX+1))
done

if [ ${#JAVA_BINARY_PATH_ARRAY[@]} -gt 0 ]
then
	. ./server_java.sh
fi


#################################
#				#
#   Ausgabe zusammenbauen	#
#				#
#################################
json_start

# Datenquelle
json_array_get_index_by_module "data_source"
json_module_key_value "hostname" "$HOSTNAME"
json_module_key_value "datetime" "$DATE_TIME" 
json_module_key_value "machine_uuid" "$MACHINE_UUID"
json_module_key_value "collector" "unix"
json_module_key_value "script_build_date" "$SCRIPT_BUILD_DATE"

for MODULE in "${JSON_MODULE_ARRAY[@]}"
do	
	json_array_get_index_by_module "$MODULE"
	if [ -n "${JSON_OUTPUT_ARRAY[$INDEX]}" ]
	then
		# Module weiter einruecken und das Haupt-Modul zusammenbauen
		MODULE_OUTPUT=`printf "${JSON_OUTPUT_ARRAY[$INDEX]}" | sed "s/^/${JSON_LEVEL_BLANKS}/"`
		JSON_OUTPUT_ARRAY[$INDEX]=""
		json_module_start_level "$MODULE"
		JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]}${MODULE_OUTPUT}
		json_module_end_level "$MODULE"		# Haupt-Modul schliessen
		#printf "\n----------\n${JSON_OUTPUT_ARRAY[$INDEX]}----------\n"
		JSON_OUTPUT=${JSON_OUTPUT}${JSON_OUTPUT_ARRAY[$INDEX]}
	fi
done
json_end

script_stop 0