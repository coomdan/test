#########################################################################################################
#                                                                                                       #
#       Projekt:        Automatisierung Lizenzmanagement (ALM)                                          #
#       Skript:         server_java.sh                                                                  #
#       Funktion:       Abfrage von Java auf Servern                                                    #
#       Version:        2                                                                               #
#                                                                                                       #
#########################################################################################################
#                                                                                                       #
#       Versionshistorie:                                                                               #
#                                                                                                       #
#       2 (13.03.2019): Falko Boehme (NSO-DSID), falko.boehme@telekom.de                                #
#               Korrektur: Java 1.6 und aelter erfassen                                                 #
#               Korrektur: Java Binary ueberpruefen                                                     #
#                                                                                                       #
#       1 (07.02.2019): Falko Boehme (NSO-DSID), falko.boehme@telekom.de                                #
#               Erste Version                                                                           #
#                                                                                                       #
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_SERVER_JAVA='2'
	
	# Java Binaries ueberpruefen
	JAVA_INDEX=1
	for JAVA_BINARY_PATH in ${JAVA_BINARY_PATH_ARRAY[@]}
	do
		JAVA_SETTINGS=`$JAVA_BINARY_PATH -XshowSettings:properties -version 2>&1`
		if [ $? -eq 0 ]
		then
			JAVA_BINARY_PATH_VALIDATED_ARRAY[$JAVA_INDEX]=$JAVA_BINARY_PATH
			JAVA_INDEX=$((JAVA_INDEX+1))
		else
			# Evt. ist das Java aelter
			JAVA_VERSION=`$JAVA_BINARY_PATH -version 2>&1 | grep version`
			if [ -n "$JAVA_VERSION" ]
			then
				JAVA_BINARY_PATH_VALIDATED_ARRAY[$JAVA_INDEX]=$JAVA_BINARY_PATH
				JAVA_INDEX=$((JAVA_INDEX+1))
			fi
		fi
	done
	
	# Ausgabe nur, wenn wir echtes Java gefunden haben
	if [ ${#JAVA_BINARY_PATH_VALIDATED_ARRAY[@]} -gt 0 ]
	then
		json_array_get_index_by_module "server_java"
		json_module_start_level "$MACHINE_UUID"
		
		for JAVA_BINARY_PATH_VALIDATED in ${JAVA_BINARY_PATH_VALIDATED_ARRAY[@]}
		do
			JAVA_SETTINGS=`$JAVA_BINARY_PATH_VALIDATED -XshowSettings:properties -version 2>&1`
			if [ $? -eq 0 ]
			then
				JAVA_PRODUCT=`echo "$JAVA_SETTINGS" | grep java.runtime.name | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
				JAVA_VERSION=`echo "$JAVA_SETTINGS" | grep java.runtime.version | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
				JAVA_VENDOR=`echo "$JAVA_SETTINGS" | grep "java.vendor " | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			else
				# altes Java
				JAVA_VERSION=`$JAVA_BINARY_PATH_VALIDATED -version 2>&1 | grep version | cut -d '"' -f2`
				JAVA_PRODUCT=`$JAVA_BINARY_PATH_VALIDATED -version 2>&1 | grep Environment`
				JAVA_VENDOR=''
			fi
			
			json_module_start_level "$JAVA_BINARY_PATH_VALIDATED"
			json_module_key_value "srv_java_machine_uuid" "$MACHINE_UUID"
			json_module_key_value "srv_java_hostname" "$HOSTNAME"
			json_module_key_value "srv_java_instance_name" "$JAVA_BINARY_PATH_VALIDATED"
			json_module_key_value "srv_java_product" "$JAVA_PRODUCT"
			json_module_key_value "srv_java_version" "$JAVA_VERSION"
			json_module_key_value "srv_java_vendor" "$JAVA_VENDOR"
			json_module_key_value "srv_java_script_version" "$SCRIPT_VERSION_SERVER_JAVA"
			json_module_key_value "srv_java_script_last_update" "$DATE_TIME"
			json_module_key_value "srv_java_is_active" "y"
			json_module_key_value "srv_java_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
			json_module_end_level
		done
		json_module_end_level
	fi
else
        echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi