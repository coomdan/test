#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		aix_device_physical.sh  							#
#	Funktion:	Abfrage der Physik unter AIX							#
#	Version:	2										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	3 (04.11.2018): Falko Boehme (T-DCI-CCDB), falko.boehme@telekom.de				#
#		Neu: Standardwerte aus der user.conf mit aufnehmen					#
#													#
#	2 (08.06.2017): Wolfgang Kurz (NSO-OSPS) w.kurz@telekom.de      				#
#		Lerrzeichen bei "phys_core_count" entfernt						#
#													#
#	1 (09.11.2016): Wolfgang Kurz (NSO-OSPS) w.kurz@telekom.de      				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_AIX_DEVICE_PHYSICAL='3'

	if [ -r $FILE_PHYSICAL_ID ]
	then
		PHYSICAL_ID=`cat $FILE_PHYSICAL_ID`
	else
		PHYSICAL_ID=`lsattr -El sys0 | grep systemid | awk '{ print$2 }'`
		
		if [ -n "$PHYSICAL_ID" ]
		then
			echo "$PHYSICAL_ID" > $FILE_PHYSICAL_ID
			chmod 444 $FILE_PHYSICAL_ID
		fi
	fi
	
	
	# geht nicht, manuelle Erfassung
	#CPU_COUNT"
	
	#CPU_CORE_COUNT
	CPU_CORE_COUNT=`lsdev|grep proc|wc -l | tr -d ' '`
		
	#CPU_THREAD_COUNT"
	PROC=`lsdev -Cc processor | head  -n1 | awk '{ print$1 }'`
	if [ `lsattr -El $PROC | grep "smt_enabled" | awk '{ print$2 }'` == "true" ]
	then	
		CPU_THREADS_PER_CORE=`lsattr -El $PROC | grep "smt_threads" | awk '{ print$2 }'`
		CPU_THREAD_COUNT=$((CPU_THREADS_PER_CORE*CPU_CORE_COUNT))
	fi
	
	
	PHYS_SERVER_MODEL=`lsattr -El sys0 | grep modelname | awk '{ print$2 }'`
	
	
	PHYS_RELATION='1:1 Relation'
	
	# Auf Virtualbox ueberpruefen
	#DUMMY=`ps -ef | grep -v grep | grep virtualbox`
	#if [ $? -eq 0 ]
	#then
	#	PHYS_RELATION="Host for virt. machines"
	#	PHYS_VIRTUALIZATION="VirtualBox"
	#fi
	
	# Auf Xen (Citrix) ueberpruefen
	#if [ -x /usr/sbin/xe ]
	#then
	#	DUMMY=`/usr/sbin/xe vm-list | wc -l`
	#	if [ $DUMMY -ge 1 ]
	#	then
	#		PHYS_RELATION="Host for virt. machines"
	#		PHYS_VIRTUALIZATION='Xen'
	#		XE_VMLIST=`/usr/sbin/xe vm-list`
	#	fi
	#fi
	
	MEMORY_KB=`lsattr -El sys0 | grep realmem | awk '{ print$2 }'`
        MEMORY_MB=$((MEMORY_KB/1024))
	
	json_array_get_index_by_module "device_physical"
	
	# eigene Physik ausgeben
	json_module_start_level "$PHYSICAL_ID"
	json_module_key_value "phys_script_version" "$SCRIPT_VERSION_AIX_DEVICE_PHYSICAL"
	json_module_key_value "phys_script_last_update" "$DATE_TIME"
	json_module_key_value "phys_device_id" "$PHYSICAL_ID"
	json_module_key_value "phys_hostname" "$HOSTNAME"
	json_module_key_value "phys_machine_uuid" "$MACHINE_UUID"
	json_module_key_value "phys_relation" "$PHYS_RELATION"
	json_module_key_value "phys_os" "$OS_TYPE"
	json_module_key_value "phys_server_model" "$PHYS_SERVER_MODEL"
	json_module_key_value "phys_cpu_model" "$CPU_MODEL"
	json_module_key_value "phys_cpu_count" "$CPU_COUNT"
	json_module_key_value "phys_core_count" "$CPU_CORE_COUNT"
	json_module_key_value "phys_thread_count" "$CPU_THREAD_COUNT"
	json_module_key_value "phys_is_active" "y"
	json_module_key_value "phys_fqdn" "$FQDN"
	json_module_key_value "phys_memory_mb" "$MEMORY_MB"
	json_module_key_value "phys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
	json_module_key_value "phys_operating_legal_entity_name" "$LEGAL_NAME"
	json_module_key_value "phys_operating_legal_entity_number" "$LEGAL_NUMBER"
	json_module_key_value "phys_operating_business_unit_name" "$BUSINESS_UNIT_NAME"
	json_module_key_value "phys_operating_accounting_area" "$ACCOUNTING_AREA"
	json_module_key_value "phys_operating_cost_center" "$COST_CENTER"
	json_module_key_value "phys_installation_country" "$COUNTRY"
	json_module_key_value "phys_installation_city" "$CITY"
	json_module_key_value "phys_installation_street" "$STREET"
	json_module_end_level
	
	if [ "$PHYS_RELATION" = "Host for virt. machines" ]
	then
		# Virtualisierung aus Physik-Sicht abfragen
		. ./linux_device_phys_for_virt.sh
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi