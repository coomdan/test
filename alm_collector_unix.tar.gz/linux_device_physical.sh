#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_physical_linux.sh							#
#	Funktion:	Abfrage der Physik unter Linux							#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	7 (04.11.2018): Falko Boehme (T-DCI-CCDB), falko.boehme@telekom.de				#
#		Neu: Standardwerte aus der user.conf mit aufnehmen					#
#													#
#	6 (02.02.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Xen Virtualisierung mit xm                                                         #
#													#
#	5 (21.11.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Abfrage von KVM-Virtualisierung                                                    #
#													#
#	4 (28.06.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Memory korrekt auslesen bei Xen-Virtualisierung (Citrix)				#
#													#
#	3 (01.09.2015): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Abfrage von Xen-Virtualisierung (Citrix)						#
#													#
#	2 (28.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Neu: Schluessel	phys_core_count und phys_thread_count					#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_LINUX_DEVICE_PHYSICAL='7'

	if [ -r $FILE_PHYSICAL_ID ]
	then
		PHYSICAL_ID=`cat $FILE_PHYSICAL_ID`
	else
		if [ -x /usr/sbin/dmidecode ]
		then
			PHYSICAL_ID=`/usr/sbin/dmidecode -t system | grep "Serial Number" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		fi
		if [ -r /sys/devices/virtual/dmi/id/chassis_serial ]
		then
			PHYSICAL_ID=`cat /sys/devices/virtual/dmi/id/chassis_serial | sed 's/^[ \t]*//;s/[ \t]*$//'`
		fi
		if [ -r /sys/devices/virtual/dmi/id/board_serial ]
		then
			PHYSICAL_ID=`cat /sys/devices/virtual/dmi/id/board_serial | sed 's/^[ \t]*//;s/[ \t]*$//'`
		fi
		if [ -r /sys/devices/virtual/dmi/id/product_serial ]
		then
			PHYSICAL_ID=`cat /sys/devices/virtual/dmi/id/product_serial | sed 's/^[ \t]*//;s/[ \t]*$//'`
		fi

		if [ -n "$PHYSICAL_ID" ]
		then
			echo "$PHYSICAL_ID" > $FILE_PHYSICAL_ID
			chmod 444 $FILE_PHYSICAL_ID
		fi
	fi
	
	if [ -x /usr/sbin/dmidecode ]
	then
		PHYS_SERVER_MODEL=`/usr/sbin/dmidecode -t system | grep "Product Name" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
	else
		if [ -r /sys/devices/virtual/dmi/id/product_name ]
		then
			PHYS_SERVER_MODEL=`cat /sys/devices/virtual/dmi/id/product_name`
		fi
	fi
	
	PHYS_RELATION='1:1 Relation'
	
	PROCESS_LIST=`ps -ef | grep -v grep`

	# Auf Virtualbox ueberpruefen
	DUMMY=`echo "$PROCESS_LIST" | grep virtualbox`
	if [ $? -eq 0 ]
	then
		PHYS_RELATION="Host for virt. machines"
		PHYS_VIRTUALIZATION="VirtualBox"
	fi

	# Auf KVM ueberpruefen
	DUMMY=`echo "$PROCESS_LIST" | grep qemu-kvm`
	if [ $? -eq 0 ]
	then
		PHYS_RELATION="Host for virt. machines"
		PHYS_VIRTUALIZATION="KVM"
	fi
	
	# Auf Xen ueberpruefen (XL_BINARY wird bereits in linux_device_cpu.sh gesetzt)
	if [ -x /usr/sbin/xe ]
	then
	        XE_BINARY="/usr/sbin/xe"
        fi
        if [ -x /opt/xensource/bin/xe ]
	then
	        XE_BINARY="/opt/xensource/bin/xe"
        fi
        if [ -x /usr/sbin/xm ]
	then
	        XM_BINARY="/usr/sbin/xm"
        fi
	if [ -n "$XE_BINARY" ]
	then
	        XE_VMLIST=`$XE_BINARY vm-list`
		DUMMY=`echo "$XE_VMLIST" | wc -l`
		if [ $DUMMY -ge 1 ]
		then
			PHYS_RELATION="Host for virt. machines"
			PHYS_VIRTUALIZATION='Xen'

			# Memory
			if [ -n "$XL_BINARY" ]
			then
				XL_INFO=`$XL_BINARY info`
				MEMORY_MB=`echo "$XL_INFO" | grep "total_memory" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`				
			fi
		fi
	fi
	if [ -n "$XM_BINARY" ]
	then
	        XM_VMLIST=`$XM_BINARY list`
		DUMMY=`echo "$XM_VMLIST" | wc -l`
		if [ $DUMMY -ge 1 ]
		then
			PHYS_RELATION="Host for virt. machines"
			PHYS_VIRTUALIZATION='Xen'

			# Memory
			if [ -n "$XL_BINARY" ]
			then
				XL_INFO=`$XL_BINARY info`
				MEMORY_MB=`echo "$XL_INFO" | grep "total_memory" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`				
			fi
		fi
	fi
	
	# Memory auslesen, wenn nicht schon etwas spezielles gesetzt wurde
	if [ -z "$MEMORY_MB" ]
	then
		MEMORY_KB=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
		MEMORY_MB=$((MEMORY_KB/1024))
	fi
	
	json_array_get_index_by_module "device_physical"
	
	# eigene Physik ausgeben
	json_module_start_level "$PHYSICAL_ID"
	json_module_key_value "phys_script_version" "$SCRIPT_VERSION_LINUX_DEVICE_PHYSICAL"
	json_module_key_value "phys_script_last_update" "$DATE_TIME"
	json_module_key_value "phys_device_id" "$PHYSICAL_ID"
	json_module_key_value "phys_hostname" "$HOSTNAME"
	json_module_key_value "phys_machine_uuid" "$MACHINE_UUID"
	json_module_key_value "phys_relation" "$PHYS_RELATION"
	json_module_key_value "phys_os" "$OS_TYPE"
	json_module_key_value "phys_server_model" "$PHYS_SERVER_MODEL"
	json_module_key_value "phys_cpu_model" "$CPU_MODEL"
	json_module_key_value "phys_cpu_count" "$CPU_COUNT"
	json_module_key_value "phys_core_count" "$CPU_CORE_COUNT"
	json_module_key_value "phys_thread_count" "$CPU_THREAD_COUNT"
	json_module_key_value "phys_is_active" "y"
	json_module_key_value "phys_fqdn" "$FQDN"
	json_module_key_value "phys_memory_mb" "$MEMORY_MB"
	json_module_key_value "phys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
	json_module_key_value "phys_operating_legal_entity_name" "$LEGAL_NAME"
	json_module_key_value "phys_operating_legal_entity_number" "$LEGAL_NUMBER"
	json_module_key_value "phys_operating_business_unit_name" "$BUSINESS_UNIT_NAME"
	json_module_key_value "phys_operating_accounting_area" "$ACCOUNTING_AREA"
	json_module_key_value "phys_operating_cost_center" "$COST_CENTER"
	json_module_key_value "phys_installation_country" "$COUNTRY"
	json_module_key_value "phys_installation_city" "$CITY"
	json_module_key_value "phys_installation_street" "$STREET"
	json_module_end_level
	
	if [ "$PHYS_RELATION" = "Host for virt. machines" ]
	then
		# Virtualisierung aus Physik-Sicht abfragen
		. ./linux_device_phys_for_virt.sh
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi