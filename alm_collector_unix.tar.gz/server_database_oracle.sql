-- ######################################################################################################
-- #													#
-- #	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
-- #	Skript:		database_oracle.sql								#
-- #	Funktion:	SQL-Abfrage von Oracle Datenbanken						#
-- #													#
-- ######################################################################################################
-- #													#
-- #	Versionshistorie:										#
-- #													#
-- #	11 (04.11.2019): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: Die Enterprise Edition hat ab Oracle 19 3 PDBs kostenlos dabei		#
-- #													#
-- #	10 (22.01.2019): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: Multitenant (count(1)-1) kann auch -1 ergeben. Abfangen			#
-- #                                                                                                    #
-- #	9 (15.01.2019): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: DBA_FUS bei Multitenatnt nicht betrachten, da eine PDB erlaubt ist 		#
-- #													#
-- #	8 (28.11.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: PDB$SEED von der Anzhal der PDBs ausnehmen und eine PDB ist erlaubt 		#
-- #													#
-- #	7 (31.10.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: decode(null) durch nvl ersetzen, hat bei Advanced Analytics gefehlt		#
-- #													#
-- #	6 (16.10.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Neu: Lizenzen, die seit 1 Jahr nicht mehr benutzt werden, gelten nicht mehr als benutzt #
-- #													#
-- #	5 (03.11.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: RAC One Node: Detektion nur ueber DBA FUS, nicht ueber gv$parameter 		#
-- #													#
-- #	4 (11.04.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: Advanced Compression interne Benutzer ausnehmen              		#
-- #													#
-- #	3 (10.01.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Korrektur: InMemory nicht bei Version 12.1.0.1 abfragen (Fehler abfangen)		#
-- #													#
-- #	2 (21.09.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Neu: Anpassungen an aeltere Oracle-Versionen (Fehler abfangen)				#
-- #													#
-- #	1 (08.03.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
-- #		Erste Version										#
-- #													#
-- ######################################################################################################
-- #													#
-- #	Database Options			| Installed	| Used					#
-- #	----------------------------------------+---------------+---------------			#
-- #	Active Data Guard			| 		| X					#
-- #	Advanced Analytics / Data Mining	| X (>=9)	| X (>=9)				#
-- #	Advanced Compression			| 		| X (>=11)				#
-- #	Advanced Security			| 		| X					#
-- #	Audit Vault (eigenes Produkt)		|		| X					#
-- #	Database In Memory			| X (>=12)	| X (>=12)				#
-- #	Database Vault				| X		| X					#
-- #	Exadata (eigenes Produkt)		|		| X					#
-- #	GoldenGate (eigenes Produkt)		|		| X					#
-- #	Label Security				| X (>=9)	| X (>=9)				#
-- #	Multitenant				| X		| X					#
-- #	OLAP					| X (>=9)	| X (>=9)				#
-- #	Partitioning				| X		| X					#
-- #	Real Application Clusters [One]		| X		| X					#
-- #	Real Application Testing		| X (>=10)	|					#
-- #	Secure Backup				|		| X					#
-- #	Spatial	and Graph			| (X)		| X					#
-- #													#
-- #													#
-- #	Database Packs				| Installed	| Used					#
-- #	----------------------------------------+---------------+---------------			#
-- #	Change Managment			|		| X (>=10)				#
-- #	Configuration				|		| X (>=10)				#
-- #	Data Masking				|		| X (>=10)				#
-- #	Diagnostic				| X (>=11)	| X (>=10)				#
-- #	Provisioning				|		| X (>=10)				#
-- #	Tuning					| X (>=11)	| X (>=10)				#
-- #	Weblogic				|		| X (>=10)				#
-- #													#
-- ######################################################################################################


-- ################
-- # Formatierung #
-- ################
set heading off;
set feedback off;
set lines 2000;
set pages 100;
alter session set NLS_DATE_FORMAT='YYYY-MM-DD HH24:Mi:ss';
set serveroutput on


declare
	eTableNotExists exception;
	eColumnNotExists exception;
	pragma exception_init(eTableNotExists, -00942);
	pragma exception_init(eColumnNotExists, -00904);
	type result_table is table of varchar2(1024) index by varchar2(128);
	type counter_table is table of number index by binary_integer;
	
	seperator constant varchar2(1) := '|';
	debug constant varchar(10) := '[debug] ';
	dba_fus_used_date_in_past date := sysdate - 366;
	result result_table;
	result_idx varchar2(128);
	cnt counter_table;
	oracle_main_version varchar2(5);
	oracle_major_version varchar2(5);
	oracle_version varchar2(10);
	sql_query varchar2(1024);

	
begin
-- ################################
-- # Werte fuer spaetere Abfragen #
-- ################################
	select substr(version, 1, instr(version, '.')-1) into oracle_main_version from v$instance;
	select substr(version, 1, instr(version, '.', 1, 2)-1) into oracle_major_version from v$instance;
	select substr(version, 1, instr(version, '.', 1, 4)-1) into oracle_version from v$instance;
	
	
	
-- ###############
-- # Allgemeines #
-- ###############
	select instance_name into result('srv_oracle_instance_name') from v$instance;
	select name into result('srv_oracle_db_name') from v$database;
	select db_unique_name into result('srv_oracle_db_unique_name') from v$database;
	select dbid into result('srv_oracle_db_id') from v$database;
	
	begin
		sql_query := 'select cpu_socket_count_highwater from v$license';
		execute immediate sql_query into result('srv_oracle_cpu_socket_count_highwater');
		exception when eColumnNotExists then result('srv_oracle_cpu_socket_count_highwater') := '';
	end;
	
	begin
		sql_query := 'select cpu_count_highwater from v$license';
		execute immediate sql_query into result('srv_oracle_cpu_count_highwater');
		exception when eColumnNotExists then result('srv_oracle_cpu_count_highwater') := '';
	end;
	
	begin
		sql_query := 'select cpu_core_count_highwater from v$license';
		execute immediate sql_query into result('srv_oracle_core_count_highwater');
		exception when eColumnNotExists then result('srv_oracle_core_count_highwater') := '';
	end;
	
	select version into result('srv_oracle_version') from v$instance;
	select created into result('srv_oracle_db_created') from v$database;
	
	select product into result('srv_oracle_product') from product_component_version where product like '%racle%';
	select min(version) into result('srv_oracle_db_created_version') from dba_feature_usage_statistics;
	select count(1) into result('srv_oracle_nup_devices_seats_count') from dba_users;
	--select stragg(comp_name||';') into result('srv_oracle_registry') from dba_registry;
	select to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS') into result('srv_oracle_last_full_scan') from dual;
	


-- ############
-- # Produkte #
-- ############	
	
-- Audit Vault
	select decode(upper(max(username)), 'AVSYS', 'y', 'n') into result('srv_oracle_audit_vault') from dba_users
		where UPPER(username) = 'AVSYS';
	

-- Exadata	
	select decode(sum(detected_usages), null,  'n', 0, 'n', 'y') into result('srv_oracle_exadata') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Exadata'
		or name='Hybrid Columnar Compression';

		
-- Goldengate
	select decode(sum(detected_usages), null,  'n', 0, 'n', 'y') into result('srv_oracle_goldengate') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='GoldenGate';		

		
-- ############
-- # Optionen #
-- ############
	
-- Active Data Guard
	select count(1) into cnt(1) from v$archive_dest_status a, v$parameter b
	where b.name = 'compatible'
	and b.value like '1%'
	and b.value not like '10%'
	and a.recovery_mode like 'MANAGED%'
	and a.status = 'VALID'
	and a.database_mode = 'OPEN_READ-ONLY';
	
	select count(1) into cnt(2) from v$block_change_tracking a, v$database b
	where b.database_role like 'PHYSICAL STANDBY'
	and a.status = 'ENABLED';
	
	select nvl(sum(detected_usages), 0) into cnt(3) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Active Data Guard - Real-Time Query on Physical Standby';
	
	if cnt(1)+cnt(2)+cnt(3) = 0
	then
		result('srv_oracle_active_data_guard_used') := 'n';
	else
		result('srv_oracle_active_data_guard_used') := 'y';
		dbms_output.put_line(debug||'active_data_guard_used_archive_dest_status: '||cnt(1));
		dbms_output.put_line(debug||'active_data_guard_used_block_change_tracking: '||cnt(2));
		dbms_output.put_line(debug||'active_data_guard_used_dbafus: '||cnt(3));
	end if;
	

-- Advanced Analytics / Data Mining
	select decode(value, 'TRUE', 'y', 'FALSE', 'n') into result('srv_oracle_advanced_analytics_installed') from v$option
		where parameter like '%Data Mining';
	
	case when oracle_major_version = '9.2' then	
			begin
				sql_query := 'select count(1) from odm.odm_mining_model';
				execute immediate sql_query into cnt(1);
				exception when eTableNotExists then cnt(1) := 0;
			end;
		when oracle_major_version = '10.1' then
			begin
				sql_query := 'select count(1) from dmsys.dm$object';
				execute immediate sql_query into cnt(2);
				exception when eTableNotExists then cnt(2) := 0;
			end;
			begin
				sql_query := 'select count(*) from dmsys.dm$model';
				execute immediate sql_query into cnt(3);
				exception when eTableNotExists then cnt(3) := 0;
			end;
			cnt(1) := cnt(2) + cnt(3);
		when oracle_major_version = '10.2' then
			begin
				sql_query := 'select count(1) from dmsys.dm$p_model';
				execute immediate sql_query into cnt(1);
				exception when eTableNotExists then cnt(1) := 0;
			end;
		else	-- Oracle 11 und groesser
			begin
				sql_query := 'select count(1) from sys.model$';
				execute immediate sql_query into cnt(2);
				exception when eTableNotExists then cnt(2) := 0;
			end;
			begin
				sql_query := 'select count(1) from sys.dba_mining_models';
				execute immediate sql_query into cnt(3);
				exception when eTableNotExists then cnt(3) := 0;
			end;
			cnt(1) := cnt(2) + cnt(3);
	end case;
	
	
	
	select nvl(sum(detected_usages), 0) into cnt(4) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Data Mining';
	
	if cnt(1)+cnt(4) = 0
	then
		result('srv_oracle_advanced_analytics_used') := 'n';
	else
		result('srv_oracle_advanced_analytics_used') := 'y';
		dbms_output.put_line(debug||'advanced_analytics_used: '||cnt(1));
		dbms_output.put_line(debug||'advanced_analytics_dbafus: '||cnt(4));
	end if;
	

-- Advanced Compression
	if oracle_main_version < 11 then
		cnt(1) := 0;
		cnt(2) := 0;
		cnt(3) := 0;
		cnt(4) := 0;
		cnt(5) := 0;
		cnt(6) := 0;
		cnt(7) := 0;
		cnt(8) := 0;
		cnt(9) := 0;
		cnt(10) := 0;
		cnt(11) := 0;
		cnt(12) := 0;
		cnt(13) := 0;
		cnt(14) := 0;
	else
		-- Tables
		begin
			sql_query := 'select count(1) from dba_tables where owner not in (''SYS'',''SYSTEM'',''SYSMAN'',''DBSNMP'') and compress_for in (''FOR ALL OPERATIONS'', ''OLTP'', ''ADVANCED'')';
			execute immediate sql_query into cnt(1);
			exception when eColumnNotExists then cnt(1) := 0;
		end;
		-- Partitions
		begin
			sql_query := 'select count(1) from dba_tab_partitions where table_owner not in (''SYS'',''SYSTEM'',''SYSMAN'',''DBSNMP'') and compress_for in (''FOR ALL OPERATIONS'',''OLTP'',''ADVANCED'')';
			execute immediate sql_query into cnt(2);
			exception when eColumnNotExists then cnt(2) := 0;
		end;
		-- Sub-Partitions
		begin
			sql_query := 'select count(1) from dba_tab_subpartitions where table_owner not in (''SYS'',''SYSTEM'',''SYSMAN'',''DBSNMP'') and compress_for in (''FOR ALL OPERATIONS'',''OLTP'',''ADVANCED'')';
			execute immediate sql_query into cnt(3);
			exception when eColumnNotExists then cnt(3) := 0;
		end;
		-- Lobs
		begin
			sql_query := 'select count(1) from dba_lobs where owner not in (''SYS'',''SYSTEM'',''SYSMAN'',''DBSNMP'') and compression not in (''NO'',''NONE'') or deduplication not in (''NO'',''NONE'')';
			execute immediate sql_query into cnt(4);
			exception when eColumnNotExists then cnt(4) := 0;
		end;
		-- Lob Partitions
		begin
			sql_query := 'select count(1) from dba_lob_partitions where table_owner not in (''SYS'',''SYSTEM'',''SYSMAN'',''DBSNMP'') and compression not in (''NO'',''NONE'') or deduplication not in (''NO'',''NONE'')';
			execute immediate sql_query into cnt(5);
			exception when eColumnNotExists then cnt(5) := 0;
		end;
		-- Lob Sub-Partitions
		begin
			sql_query := 'select count(1) from dba_lob_subpartitions where table_owner not in (''SYS'',''SYSTEM'',''SYSMAN'',''DBSNMP'') and compression not in (''NO'',''NONE'') or deduplication not in (''NO'',''NONE'')';
			execute immediate sql_query into cnt(6);
			exception when eColumnNotExists then cnt(6) := 0;
		end;
		-- Dataguard
		select count(value) into cnt(7) from v$parameter
			where upper(name)  like '%LOG_ARCHIVE_DEST%'
			and upper(value) like '%COMPRESSION=ENABLE%';
		select nvl(sum(detected_usages), 0) into cnt(8) from dba_feature_usage_statistics
			where last_usage_date > dba_fus_used_date_in_past
			and name = 'Data Guard'
			and (dbms_lob.substr(FEATURE_INFO, 200, 1) != ''
				and dbms_lob.substr(FEATURE_INFO, 200, 1) like '%Compression used: TRUE%');
		-- Datapump
		select nvl(sum(detected_usages), 0) into cnt(9) from dba_feature_usage_statistics
			where last_usage_date > dba_fus_used_date_in_past
			and (name='Oracle Utility Datapump (Export)' or name='Oracle Utility Datapump (Import)')
			and (dbms_lob.substr(FEATURE_INFO, 200, 1) != ''
				and dbms_lob.substr(FEATURE_INFO, 200, 1) not like '%compression used: 0 times%');
		-- Tablespaces
		begin
			sql_query := 'select count(1) from dba_tablespaces where def_tab_compression != ''DISABLED'' and compress_for not in (''BASIC'',''N/A'')';
			execute immediate sql_query into cnt(10);
			exception when eColumnNotExists then cnt(10) := 0;
		end;
		-- Backup Compression (BZIP2 und BASIC sind Lizenzfrei -> siehe v$rman_compression_algorithm)
		select nvl(sum(detected_usages), 0) into cnt(11) from dba_feature_usage_statistics a
			left join (select dbid, name, version, dbms_lob.substr(feature_info, 4000, 1) feature_info from dba_feature_usage_statistics) b
			on (a.dbid=b.dbid 
				and a.name=b.name
				and a.version=b.version
			)
			where a.last_usage_date > dba_fus_used_date_in_past
			and (
				a.name='Backup HIGH Compression'
				or a.name='Backup LOW Compression'
				or a.name='Backup MEDIUM Compression'
				or a.name='Backup ZLIB Compression'
				or a.name='Flashback Data Archive'
				or a.name='SecureFile Compression (user)'
				or a.name='SecureFile Deduplication (user)'
				or (a.name='Data Guard' and b.feature_info like '%ompression used: TRUE%')
				or (a.name='Oracle Utility Datapump (Export)' and b.feature_info like '%ompression used%' and b.feature_info not like '%ompression used: 0 times%')
				or (a.name='Oracle Utility Datapump (Import)' and b.feature_info like '%ompression used%' and b.feature_info not like '%ompression used: 0 times%')
			);
		-- Heap-Compression
		begin
			sql_query := 'select (ac_table_count * ac_heapcomp_count) from
			(
				select count(*) as ac_table_count from dba_tables
				where compression != ''DISABLED''
				and owner not in (''SYS'',''SYSTEM'',''SYSMAN'',''DBSNMP'')
				and compress_for not in (''BASIC'', ''N/A'')
			),(
				select nvl(sum(detected_usages), 0) as ac_heapcomp_count from dba_feature_usage_statistics
				where last_usage_date > dba_fus_used_date_in_past
				and name=''HeapCompression''
			)';
			execute immediate sql_query into cnt(12);
			exception when eColumnNotExists then cnt(12) := 0;
		end;
		
		-- Flashback Data Archive
		begin
			sql_query := 'select count(1) from dba_flashback_archive a	left join dba_flashback_archive_ts b on a.flashback_archive# = b.flashback_archive#';
			execute immediate sql_query into cnt(13);
			exception when eColumnNotExists then cnt(13) := 0;
		end;
		begin
			sql_query := 'select count(1) from dba_flashback_archive_tables';
			execute immediate sql_query into cnt(14);
			exception when eColumnNotExists then cnt(14) := 0;
		end;
	end if;
	
	if cnt(1)+cnt(2)+cnt(3)+cnt(4)+cnt(5)+cnt(6)+cnt(7)+cnt(8)+cnt(9)+cnt(10)+cnt(11)+cnt(12)+cnt(13)+cnt(14) = 0
	then
		result('srv_oracle_advanced_compression_used') := 'n';
	else
		result('srv_oracle_advanced_compression_used') := 'y';
		dbms_output.put_line(debug||'advanced_compression_used_tables: '||cnt(1));
		dbms_output.put_line(debug||'advanced_compression_used_partitions: '||cnt(2));
		dbms_output.put_line(debug||'advanced_compression_used_subpartitions: '||cnt(3));
		dbms_output.put_line(debug||'advanced_compression_used_lobs: '||cnt(4));
		dbms_output.put_line(debug||'advanced_compression_used_lob_partitions: '||cnt(5));
		dbms_output.put_line(debug||'advanced_compression_used_lob_subpartitions: '||cnt(6));
		dbms_output.put_line(debug||'advanced_compression_used_dataguard_parameter: '||cnt(7));
		dbms_output.put_line(debug||'advanced_compression_used_dataguard_dbafus: '||cnt(8));
		dbms_output.put_line(debug||'advanced_compression_used_datapump: '||cnt(9));
		dbms_output.put_line(debug||'advanced_compression_used_tablespaces: '||cnt(10));
		dbms_output.put_line(debug||'advanced_compression_used_dbafus_backup: '||cnt(11));
		dbms_output.put_line(debug||'advanced_compression_used_dbafus_heap: '||cnt(12));
		dbms_output.put_line(debug||'advanced_compression_used_flashback_archive: '||cnt(13));
		dbms_output.put_line(debug||'advanced_compression_used_flashback_archive_tables: '||cnt(14));
	end if;


-- Advanced Security
	if oracle_main_version < 11 then
		cnt(1) := 0;
		cnt(2) := 0;
		cnt(3) := 0;
		cnt(4) := 0;
		cnt(5) := 0;
		cnt(6) := 0;
	else
		-- Encrypted Columns
		begin
			sql_query := 'select count(*) from dba_encrypted_columns';
			execute immediate sql_query into cnt(1);
			exception when eColumnNotExists then cnt(1) := 0;
			end;
		-- Encrypted Tablespaces
		begin
			sql_query := 'select count(*) from dba_tablespaces where encrypted =''YES''';
			execute immediate sql_query into cnt(2);
			exception when eColumnNotExists then cnt(2) := 0;
		end;
		-- Lobs
		begin
			sql_query := 'select count(1) from dba_lobs where encrypt not in (''NO'', ''NONE'')';
			execute immediate sql_query into cnt(3);
			exception when eColumnNotExists then cnt(3) := 0;
		end;
		-- Lob Partitions
		begin
			sql_query := 'select count(1) from dba_lob_partitions where encrypt not in (''NO'', ''NONE'')';
			execute immediate sql_query into cnt(4);
			exception when eColumnNotExists then cnt(4) := 0;
		end;
		-- Lob Sub-Partitions
		begin
			sql_query := 'select count(1) from dba_lob_subpartitions where encrypt not in (''NO'', ''NONE'')';
			execute immediate sql_query into cnt(5);
			exception when eColumnNotExists then cnt(5) := 0;
		end;
		
		-- DBA FUS
		select nvl(sum(detected_usages), 0) into cnt(6) from dba_feature_usage_statistics
			where last_usage_date > dba_fus_used_date_in_past
			and (
				name='Transparent Data Encryption'
				or name='Encrypted Tablespaces'
				or name='Backup Encryption'
				or name='SecureFile Encryption (user)'
			);
	end if;
	
	if cnt(1)+cnt(2)+cnt(3)+cnt(4)+cnt(5)+cnt(6) = 0
	then
		result('srv_oracle_advanced_security_used') := 'n';
	else
		result('srv_oracle_advanced_security_used') := 'y';
		dbms_output.put_line(debug||'advanced_security_used_columns: '||cnt(1));
		dbms_output.put_line(debug||'advanced_security_used_tablespaces: '||cnt(2));
		dbms_output.put_line(debug||'advanced_security_used_lobs: '||cnt(3));
		dbms_output.put_line(debug||'advanced_security_used_lob_partitions: '||cnt(4));
		dbms_output.put_line(debug||'advanced_security_used_lob_subpartitions: '||cnt(5));
		dbms_output.put_line(debug||'advanced_security_used_dbafus: '||cnt(6));
	end if;

	
-- Database In Memory
	if (oracle_main_version < 12) or (oracle_version = '12.1.0.1') then
		cnt(1) := 0;
		cnt(2) := 0;
		cnt(3) := 0;
		cnt(4) := 0;
		cnt(5) := 0;
		cnt(6) := 0;
	else
		select decode(value, null, 'n', 'DISABLE', 'n', 'y') into result('srv_oracle_in_memory_database_cache_installed') from v$parameter
			where name='inmemory_query';
		
		select decode(value, null, 0, value) into cnt(1) from v$parameter
			where name='inmemory_size';
		-- Tables
		begin
			sql_query := 'select count(1) from dba_tables where inmemory = ''ENABLED''';
			execute immediate sql_query into cnt(2);
			exception when eColumnNotExists then cnt(2) := 0;
		end;
		-- Partitions
		begin
			sql_query := 'select count(1) from dba_tab_partitions where inmemory = ''ENABLED''';
			execute immediate sql_query into cnt(3);
			exception when eColumnNotExists then cnt(3) := 0;
		end;
		-- Sub-Partitions
		begin
			sql_query := 'select count(1) from dba_tab_subpartitions where inmemory = ''ENABLED''';
			execute immediate sql_query into cnt(4);
			exception when eColumnNotExists then cnt(4) := 0;
		end;
		-- Object-Tables
		begin
			sql_query := 'select count(1) from dba_object_tables where inmemory = ''ENABLED''';
			execute immediate sql_query into cnt(5);
			exception when eColumnNotExists then cnt(5) := 0;
		end;	
	end if;
	
	select nvl(sum(detected_usages), 0) into cnt(6) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='In-Memory Aggregation';
	
	if cnt(1)+cnt(2)+cnt(3)+cnt(4)+cnt(5)+cnt(6) = 0
	then
		result('srv_oracle_in_memory_database_cache_used') := 'n';
	else
		result('srv_oracle_in_memory_database_cache_used') := 'y';
		dbms_output.put_line(debug||'in_memory_database_cache_used_parameter: '||cnt(1));
		dbms_output.put_line(debug||'in_memory_database_cache_used_table: '||cnt(2));
		dbms_output.put_line(debug||'in_memory_database_cache_used_partitions: '||cnt(3));
		dbms_output.put_line(debug||'in_memory_database_cache_used_subpartition: '||cnt(4));
		dbms_output.put_line(debug||'in_memory_database_cache_used_object_table: '||cnt(5));
		dbms_output.put_line(debug||'in_memory_database_cache_used_dbafus: '||cnt(6));
	end if;		
	

-- Database Vault
	select decode(upper(max(username)), 'DVSYS', 1, 0) into cnt(1) from dba_users where UPPER(username) = 'DVSYS';
	select decode(upper(max(username)), 'DVF', 1, 0) into cnt(2) from dba_users where UPPER(username) = 'DVF';
	
	if cnt(1)+cnt(2) = 0
	then
		result('srv_oracle_database_vault_installed') := 'n';
	else
		result('srv_oracle_database_vault_installed') := 'y';
		dbms_output.put_line(debug||'database_vault_installed_dvsys: '||cnt(1));
		dbms_output.put_line(debug||'database_vault_installed_dvf: '||cnt(2));
	end if;
	
	begin
		sql_query := 'select count(*) from dvsys.dba_dv_realm';
		execute immediate sql_query into cnt(1);
		exception when eTableNotExists then cnt(1) := 0;
	end;
	select nvl(sum(detected_usages), 0) into cnt(2) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Oracle Database Vault';
		
	if cnt(1)+cnt(2) = 0
	then
		result('srv_oracle_database_vault_used') := 'n';
	else
		result('srv_oracle_database_vault_used') := 'y';
		dbms_output.put_line(debug||'database_vault_used_dba_dv_realm: '||cnt(1));
		dbms_output.put_line(debug||'database_vault_used_dbafus: '||cnt(2));
	end if;	


-- Label Security
	select decode(value, null, 'n', 'FALSE', 'n', 'y') into result('srv_oracle_label_security_installed') from v$option
		where parameter like '%Label Security%';
	
	begin
		sql_query := 'select count(*) from lbacsys.lbac$polt where owner != ''SA_DEMO''';
		execute immediate sql_query into cnt(1);
		exception when eTableNotExists then cnt(1) := 0;
	end;
	
	select nvl(sum(detected_usages), 0) into cnt(2) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Label Security';
	
	if cnt(1)+cnt(2) = 0
	then
		result('srv_oracle_label_security_used') := 'n';
	else
		result('srv_oracle_label_security_used') := 'y';
		dbms_output.put_line(debug||'label_security_used_lbacsys: '||cnt(1));
		dbms_output.put_line(debug||'label_security_used_dbafus: '||cnt(2));
	end if;
	

-- Multitenant	
	if oracle_main_version < 12 then
		cnt(1) := 0;
		cnt(2) := 0;
	else
		begin
			sql_query := 'select decode(cdb, null, 0, ''NO'', 0, 1) from v$database';
			execute immediate sql_query into cnt(1);
			exception when eColumnNotExists then cnt(1) := 0;
		end;
		
		begin
			sql_query := 'select decode(count(1), null, 0, count(1)) from v$containers where con_id = 1';
			execute immediate sql_query into cnt(2);
			exception when eTableNotExists then cnt(2) := 0;
		end;
	end if;

	if cnt(1) = 0
	then
		result('srv_oracle_multitenant_installed') := 'n';
	else
		result('srv_oracle_multitenant_installed') := 'y';
		dbms_output.put_line(debug||'multitenant_installed_cdb: '||cnt(1));
		dbms_output.put_line(debug||'multitenant_installed_container: '||cnt(2));
	end if;
	
	
	if oracle_main_version < 12 then
		cnt(1) := 0;
		-- cnt(2) := 0;
	else
		begin
		        -- CDB$ROOT, PDB$SEED und eine PDB sind lizenzkostenfrei
			sql_query := 'select decode((count(1)-1), null, ''n'', (count(1)-1)) from dba_pdbs where pdb_name != ''CDB$ROOT'' and  pdb_name != ''PDB$SEED''';
			execute immediate sql_query into cnt(1);
			exception when eTableNotExists then cnt(1) := 0;
		end;
		-- count(1)-1 kann auch -1 ergeben, das muss abgefangen werden
	        if cnt(1) = -1
		then
                        cnt(1) := 0;
                end if;
	        
	        -- multitenant wird in dba_fus auch bei einer PDB angezeigt, daher kann man es fuer eine Lizenzaussage nicht verwenden
		-- select nvl(sum(detected_usages), 0) into cnt(2) from dba_feature_usage_statistics
		--	where last_usage_date > dba_fus_used_date_in_past
		--	and name='Oracle Multitenant';
		
	end if;
	
	if cnt(1) = 0
	then
		result('srv_oracle_multitenant_used') := 'n';
	else
		-- ab Oracle 19 sind 3 PDBs kostenfrei erlaubt
		if oracle_main_version < 19
		then
			result('srv_oracle_multitenant_used') := 'y';
			dbms_output.put_line(debug||'multitenant_used_pdb: '||cnt(1));
		else
			if cnt(1) < 3
			then
				result('srv_oracle_multitenant_used') := 'n';
			else
				result('srv_oracle_multitenant_used') := 'y';
				dbms_output.put_line(debug||'multitenant_used_pdb: '||cnt(1));
			end if;
		end if;
		-- dbms_output.put_line(debug||'multitenant_used_dbafus: '||cnt(2));
	end if;
	
	
-- OLAP	
	select decode(value, null, 'n', 'FALSE', 'n', 'y') into result('srv_oracle_olap_installed') from v$option
		where parameter='OLAP';
	
	begin
		sql_query := 'select count(1) from olapsys.dba$olap_cubes where owner != ''SH''';
		execute immediate sql_query into cnt(1);
		exception when eTableNotExists then cnt(1) := 0;
	end;
		
	begin
		sql_query := 'select count(1) from dba_cubes where owner != ''SH''';
		execute immediate sql_query into cnt(2);
		exception when eTableNotExists then cnt(2) := 0;
	end;
	
	select count(1) into cnt(3) from dba_aws
		where owner not in ('SYS', 'SYSTEM');
	
	select nvl(sum(detected_usages), 0) into cnt(4) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name like 'OLAP - %';
	
	if cnt(1)+cnt(2)+cnt(3)+cnt(4) = 0
	then
		result('srv_oracle_olap_used') := 'n';
	else
		result('srv_oracle_olap_used') := 'y';
		dbms_output.put_line(debug||'olap_dba$olap_cubes: '||cnt(1));
		dbms_output.put_line(debug||'olap_dba_cubes: '||cnt(2));
		dbms_output.put_line(debug||'olap_dba_aws: '||cnt(3));
		dbms_output.put_line(debug||'olap_dbafus: '||cnt(4));
	end if;
	
	
-- Partitioning
	select decode(value, null, 'n', 'FALSE', 'n', 'y') into result('srv_oracle_partitioning_installed') from v$option
		where parameter='Partitioning';
	
	select count(distinct owner) into cnt(1) from dba_objects
		where object_type like '%PARTITION%'
		and owner not in ('SYS', 'SYSTEM', 'AUDSYS');
	
	begin
		sql_query := 'select count(distinct owner) from dba_recyclebin
			where partition_name is not null 
			and owner not in (''SYS'', ''SYSTEM'', ''AUDSYS'')';
		execute immediate sql_query into cnt(2);
		exception when eTableNotExists then cnt(2) := 0;
	end;
	
	select nvl(sum(detected_usages), 0) into cnt(3) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and (
			name='Partitioning (user)'
			or name='Semantics/RDF'
		);
	
	if cnt(1)+cnt(2)+cnt(3) = 0
	then
		result('srv_oracle_partitioning_used') := 'n';
	else
		result('srv_oracle_partitioning_used') := 'y';
		dbms_output.put_line(debug||'partitioning_used_segments: '||cnt(1));
		dbms_output.put_line(debug||'partitioning_used_recyclebin: '||cnt(2));
		dbms_output.put_line(debug||'partitioning_used_dbafus: '||cnt(3));
	end if;
	
	
-- Real Application Clusters
	select decode(value, null, 'n', 'FALSE', 'n', 'y') into result('srv_oracle_real_application_clusters_installed') from v$option
		where parameter in ('Real Application Clusters','Parallel Server');
		
	select count(*) into cnt(1) from gv$parameter
		where name = 'cluster_database'
		and value='TRUE';
	
	--case cnt(1)
	--	when 0 then
	--		cnt(2) := 0;
	--		result('srv_oracle_real_application_clusters_one_node_used') := 'n';
	--	when 1 then 
	--		result('srv_oracle_real_application_clusters_one_node_used') := 'y';
	--	else
	--		cnt(2) := 1;
	--		result('srv_oracle_real_application_clusters_one_node_used') := 'n';
	--end case;
	
	select nvl(sum(detected_usages), 0) into cnt(2) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and (
			name='Real Application Clusters (RAC)'
			or name='Quality of Service Management'
			or name='Clusterwide Global Transactions'
			or name='Internode Parallel Execution'
			or name='SQL Workload Manager'
		);
	
	if cnt(1)+cnt(2) = 0
	then
		result('srv_oracle_real_application_clusters_used') := 'n';
	else
		result('srv_oracle_real_application_clusters_used') := 'y';
		dbms_output.put_line(debug||'real_application_clusters_used_parameter: '||cnt(1));
		dbms_output.put_line(debug||'real_application_clusters_used_dbafus: '||cnt(2));
	end if;
	
	
-- Real Application Clusters One Node
	select nvl(sum(detected_usages), 0) into cnt(1) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Real Application Cluster One Node';
		
	if cnt(1) = 0
	then
		result('srv_oracle_real_application_clusters_one_node_used') := 'n';
	else
		result('srv_oracle_real_application_clusters_one_node_used') := 'y';
		dbms_output.put_line(debug||'srv_oracle_real_application_clusters_one_node_used_dbafus: '||cnt(1));
	end if;
	
	
-- Real Application Testing
	begin
	        select decode(value, null, 'n', 'FALSE', 'n', 'y') into result('srv_oracle_real_application_testing_installed') from v$option where parameter='Real Application Testing';
	        exception when NO_DATA_FOUND then result('srv_oracle_real_application_testing_installed') := 'n';
        end;
        
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_real_application_testing_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and (
			name='Database Replay: Workload Capture'
			or name='Database Replay: Workload Replay'
			or name='SQL Performance Analyzer'
		);
	
	
-- Secure Backup
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_secure_backup_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Oracle Secure Backup';
		
	
-- Spatial and Graph
	begin
		sql_query := 'select count(1) from all_sdo_geom_metadata';
		execute immediate sql_query into cnt(1);
		exception when eTableNotExists then cnt(1) := 0;
	end;
	
	select nvl(sum(detected_usages), 0) into cnt(2) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and (
			name='Spatial'
			or name='Semantics/RDF'
		);
	
	if cnt(1)+cnt(2) = 0
	then
		result('srv_oracle_spatial_and_graph_used') := 'n';
	else
		result('srv_oracle_spatial_and_graph_used') := 'y';
		dbms_output.put_line(debug||'spatial_used_all_sdo_geom_metadata: '||cnt(1));
		dbms_output.put_line(debug||'spatial_used_dbafus '||cnt(2));
	end if;
	
	
	
-- #########
-- # Packs #
-- #########

-- Change Management Pack
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_change_management_pack_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Change Management Pack (GC)';


-- Configuration Management Pack
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_configuration_management_pack_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='EM Config Management Pack (GC)';

		
-- Data Masking Pack
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_data_masking_pack_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='Data Masking Pack (GC)';
		

-- Diagnostic Pack
	select decode(count(1), null, 'n', 0, 'n', 'y') into result('srv_oracle_diagnostic_pack_installed') from v$parameter
		where name='control_management_pack_access'
		and value like '%DIAGNOSTIC%';
	
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_diagnostic_pack_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and (
			name='Diagnostic Pack'
			or name='ADDM'
			or name='Automatic Workload Repository'
			or name='AWR Baseline'
			or name='AWR Baseline Template'
			or name='AWR Report'
			or name='Baseline Adaptive Thresholds'
			or name='EM Performance Page'
			or name='SQL Performance Analyzer'
		);


-- Provisioning Pack
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_provisioning_pack_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and (
			name='EM Database Provisioning and Patch Automation (GC)'
			or name='EM Standalone Provisioning and Patch Automation Pack (GC)'
		);

		
-- Tuning Pack
	select decode(count(1), null, 'n', 0, 'n', 'y') into result('srv_oracle_tuning_pack_installed') from v$parameter
		where  name='control_management_pack_access'
		and value like '%TUNING%';
	-- SQL Profiles
	select count(1) into cnt(1) from dba_sql_profiles
		where upper(status) = 'ENABLED';
	-- Advisor Tasks
	select count(1) into cnt(2) from dba_advisor_tasks
		where advisor_name in ('SQL Tuning Advisor', 'SQL Access Advisor')
		and not (owner='SYS' and task_name='SYS_AUTO_SQL_TUNING_TASK' and description='Automatic SQL Tuning Task');
	-- SQL Set
	select count(1) into cnt(3) from dba_sqlset;
	-- SQL Set Reference
	select count(1) into cnt(4) from dba_sqlset_references;
	--- DBA FUS
	select nvl(sum(detected_usages), 0) into cnt(5) from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and (
			name='SQL Access Advisor'
			or name='SQL Monitoring and Tuning pages'
			or name='SQL Profile'
			or name='SQL Tuning Advisor'
			--or name='Tune MView'
			--or name='Real-Time SQL Monitoring'
			or name='SQL Tuning Set (user)'
		);
	
	if cnt(1)+cnt(2)+cnt(3)+cnt(4)+cnt(5) = 0
	then
		result('srv_oracle_tuning_pack_used') := 'n';
	else
		result('srv_oracle_tuning_pack_used') := 'y';
		dbms_output.put_line(debug||'tuning_pack_used_sql_profiles: '||cnt(1));
		dbms_output.put_line(debug||'tuning_pack_used_advisory_tasks '||cnt(2));
		dbms_output.put_line(debug||'tuning_pack_used_sql_set: '||cnt(3));
		dbms_output.put_line(debug||'tuning_pack_used_sql_set_reference '||cnt(4));
		dbms_output.put_line(debug||'tuning_pack_used_dbafus: '||cnt(5));
	end if;
		
-- Weblogic Pack
	select decode(sum(detected_usages), null, 'n', 0, 'n', 'y') into result('srv_oracle_weblogic_pack_used') from dba_feature_usage_statistics
		where last_usage_date > dba_fus_used_date_in_past
		and name='EM AS Provisioning and Patch Automation (GC)';
		
		
		
-- ###########
-- # Ausgabe #
-- ###########
        dbms_output.put_line('dummy empty line');       -- Leerzeile am Anfang, damit der grep ^srv_oracle nicht eine Zeile verschluckt
	result_idx := result.first;
	while (result_idx is not null)
	loop
		dbms_output.put_line(result_idx||seperator||result(result_idx));
		result_idx := result.next(result_idx);
	end loop;
end;
/
quit;