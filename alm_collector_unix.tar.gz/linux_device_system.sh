#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_system_linux.sh								#
#	Funktion:	Abfrage des Systems unter Linux							#
#	Version:	1										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	3 (04.11.2018): Falko Boehme (T-DCI-CCDB), falko.boehme@telekom.de				#
#		Neu: Standardwerte aus der user.conf mit aufnehmen					#
#													#
#	2 (12.09.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Abbrechen, falls das Skript auf einem alten VMware	Host laeuft                     #
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_LINUX_DEVICE_SYSTEM='3'
	
	if [ -r /etc/SuSE-release ] && [ -z "$OS_NAME" ]
	then
		SUSE_RELEASE=`cat /etc/SuSE-release`
		OS_NAME=`echo "$SUSE_RELEASE" | head -1`        # erste Zeile
		OS_VERSION=`echo "$SUSE_RELEASE" | head -2 | tail -1 | cut -d '=' -f2 | awk '{print $1}'`       # zweite Zeile
		OS_SUBVERSION=`echo "$SUSE_RELEASE" | head -3 | tail -1 | cut -d '=' -f2 | awk '{print $1}'`    # dritte Zeile
	fi
	
	if [ -r /etc/oracle-release ] && [ -z "$OS_NAME" ]
	then
		ORACLE_RELEASE=`cat /etc/oracle-release`
		POS_RELEASE=`awk -v ORACLE_RELEASE="$ORACLE_RELEASE" 'BEGIN{print index(ORACLE_RELEASE, "release")}'`
		OS_NAME=`echo ${ORACLE_RELEASE:0:$((POS_RELEASE-2))}`	# Leerzeichen und r von release entfernen
		OS_VERSION=`echo ${ORACLE_RELEASE:$((POS_RELEASE+7))}`	# release und Leerzeichen entfernen
		OS_SUBVERSION=`uname -r`
	fi
	
	if [ -r /etc/redhat-release ] && [ -z "$OS_NAME" ]
	then
		REDHAT_RELEASE=`cat /etc/redhat-release`
		POS_RELEASE=`awk -v REDHAT_RELEASE="$REDHAT_RELEASE" 'BEGIN{print index(REDHAT_RELEASE, "release")}'`
		OS_NAME=`echo ${REDHAT_RELEASE:0:$((POS_RELEASE-2))}`	# Leerzeichen und r von release entfernen
		OS_VERSION=`echo ${REDHAT_RELEASE:$((POS_RELEASE+7))}`	# release und Leerzeichen entfernen
		OS_SUBVERSION=`uname -r`
	fi

	if [ -r /etc/lsb-release ] && [ -z "$OS_NAME" ]
	then
		LSB_RELEASE=`cat /etc/lsb-release`
		OS_NAME=`echo "$LSB_RELEASE" | grep DISTRIB_ID | cut -d '=' -f2`
		OS_VERSION=`echo "$LSB_RELEASE" | grep DISTRIB_RELEASE | cut -d '=' -f2`
		OS_SUBVERSION=`uname -r`
	fi
	
	# Wenn wir Host fuer VMware sind abbrechen. Das soll ueber ein VCenter ausgelesen werden
	DUMMY=`echo "$OS_SUBVERSION" | grep ESX`
	if [ $? -eq 0 ]
	then
	        echo "This is a Host for VMware Virtualization."
	        echo "Please use the VMware Collector to query the hardware configuration."
	        echo "Aborting"
	        script_stop 100
	fi
	
	json_array_get_index_by_module "device_system"
	
	json_module_start_level "$MACHINE_UUID"
	json_module_key_value "sys_script_version" "$SCRIPT_VERSION_LINUX_DEVICE_SYSTEM"
	json_module_key_value "sys_script_last_update" "$DATE_TIME"
	json_module_key_value "sys_hostname" "$HOSTNAME"
	json_module_key_value "sys_machine_uuid" "$MACHINE_UUID"
	json_module_key_value "sys_is_active" "y"
	json_module_key_value "sys_fqdn" "$FQDN"
	json_module_key_value "sys_os_type" "$OS_TYPE"
	json_module_key_value "sys_os_name" "$OS_NAME"
	json_module_key_value "sys_os_version" "$OS_VERSION"
	json_module_key_value "sys_os_subversion" "$OS_SUBVERSION"
	json_module_key_value "sys_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
	json_module_key_value "sys_installation_legal_entity_name" "$LEGAL_NAME"
	json_module_key_value "sys_installation_legal_entity_number" "$LEGAL_NUMBER"
	json_module_key_value "sys_installation_business_unit_name" "$BUSINESS_UNIT_NAME"
	json_module_key_value "sys_installation_accounting_area" "$ACCOUNTING_AREA"
	json_module_key_value "sys_installation_cost_center" "$COST_CENTER"
	json_module_key_value "sys_environment" "$ENVIRONMENT"
	json_module_end_level
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi