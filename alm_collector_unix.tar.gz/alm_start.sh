#!/usr/bin/env bash
CREATE_CRON_JOB=$1

# Initialisierung
WORK_DIR=`dirname $0`
if [ "$WORK_DIR" = "." ]
then
        WORK_DIR=`pwd`
fi
cd $WORK_DIR

if [ -r "./user.conf" ]
then
        . ./user.conf
fi
. ./.alm_environment.conf
. ./alm.conf

if [ -n "$OUTPUT_DIR" ]
then
        ALM_OUTPUT_DIR=$OUTPUT_DIR
fi
if [ -z "$DESTINATION_IP" ]
then
        DESTINATION_IP="10.90.122.83"
fi
if [ -z "$DATA_SOURCE" ]
then
        DATA_SOURCE="curl"
fi



REST_API_URL="https://$DESTINATION_IP/$ALM_ENV/$DATA_SOURCE"

# start alm_collector
$ALM_COLLECTOR
EXIT_CODE=$?
ALM_OUTPUT_FILE=`find $ALM_OUTPUT_DIR -name "*$ALM_EXTENSION" -user root | tail -1`

if [ "$EXIT_CODE" -ne 0 ] && [ "$EXIT_CODE" -ne 255 ]
then
        if [ -n "$ALM_OUTPUT_FILE" ]
        then
                cat $ALM_OUTPUT_FILE
        else
                echo "Please run '$ALM_COLLECTOR 1' manually, to check for errors"
        fi
	exit $EXIT_CODE
fi

if [ -n "$ALM_OUTPUT_FILE" ]
then
        # Upload File
        if [ -n "$PROXY_SERVER" ]
        then
                export HTTPS_PROXY=$PROXY_SERVER
        fi
        
        if [ -x "$CURL_BINARY" ]
        then
                $CURL_BINARY --request PUT --max-time 10 --cacert $ALM_CERT --data @$ALM_OUTPUT_FILE $REST_API_URL
                if [ $? -ne 0 ]
                then
                # Upload ohne Zertifikat versuchen
                        echo "Upload failed. Trying upload with '$CURL_BINARY' ignoring the certificate"
                        $CURL_BINARY --request PUT --max-time 10 -k --data @$ALM_OUTPUT_FILE $REST_API_URL
                fi
        else
                $ALM_PUT_SCRIPT $ALM_OUTPUT_FILE $REST_API_URL
        fi
        
        # Housekeeping
        rm $ALM_OUTPUT_FILE
fi

if [ "$CREATE_CRON_JOB" = "cron" ]
then
        if [ -n "$RANDOM" ]
        then
                TMP_CRONTAB="/tmp/crontab.${RANDOM}.tmp"
                crontab -l > $TMP_CRONTAB
                ALM_START_BASENAME=`basename $ALM_START`
                DUMMY=`grep $ALM_START_BASENAME $TMP_CRONTAB`
                if [ $? -eq 0 ]
                then
                        # alten Crontab-Eintrag loeschen
                        NEW_TMP_CRONTAB="/tmp/crontab.${RANDOM}.new.tmp"
                        cat "$TMP_CRONTAB" | grep -v "# Automatic License Management" | grep -v "$ALM_START_BASENAME 2>&1 > /dev/null" > $NEW_TMP_CRONTAB
                        mv $NEW_TMP_CRONTAB $TMP_CRONTAB
                fi
                echo "installing new crontab"
                WEEKDAY=`echo $(($RANDOM % 6))`
                HOUR=`echo $(($RANDOM % 23))`
                MINUTE=`echo $(($RANDOM % 60))`
                SECOND=`echo $(($RANDOM % 60))`
                CRONTAB_ENTRY="$MINUTE $HOUR * * $WEEKDAY $SLEEP_BINARY $SECOND && $ALM_START 2>&1 > /dev/null"
                echo "# Automatic License Management" >> $TMP_CRONTAB
                echo "$CRONTAB_ENTRY" >> $TMP_CRONTAB
                crontab $TMP_CRONTAB
                rm $TMP_CRONTAB
        fi
fi