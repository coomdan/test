#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		server_database_oracle.sh							#
#	Funktion:	Abfrage von Oracle Datenbanken							#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#       10 (20.11.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de               		#
#               Neu: FlexASM-Instanzen rausfiltern (+APX)                                               #
#                                                                                                       #
#       9 (23.05.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de               			#
#               Korrektur: Audit Vault, Exadata und Goldengate werden nicht mehr seperat erfasst        #
#                                                                                                       #
#       8 (15.12.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de               			#
#               Korrektur: Ausgabe, wenn Instanz nicht laeuft                                           #
#													#
#       7 (18.10.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de               			#
#               Korrektur: Vor dem Connect auf eine Instanz, wir ueberprueft, ob sie laeuft             #
#													#
#       6 (10.07.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de               			#
#		Neu: Laufende Instanzen werden als aktiv gemeldet, oratab-Instanzen nur aufgefuehrt     #
#               Korrektur: grep in $ORACLE_OWNER_HOME/.alm_oracle.profile nach kompletter ORACLE_SID    # 
#               Korrektur: Ueberpruefen of es ueberhaupt eine oratab gibt                               #
#													#
#       5 (17.01.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de               			#
#		Korrektur: Skript-Uebergabe an sqlplus                               		        #
#													#
#       4 (06.12.2016): Wolfgang Kurz (NSO-OSPS), w.kurz@telekom.de               			#
#		Neu: Beruecksichtigung von AIX bei der Ermittlung von ORACLE_HOME     		        #
#                                                                                                       #
#       3 (16.11.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Beruecksichtigung von Links bei der Ermittlung von ORACLE_HOME     		#
#													#
#	2 (22.09.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Beruecksichtigung der oratab fuer zu scannende Datenbanken				#
#													#
#	1 (08.03.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################


# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_DATABASE_ORACLE='10'
	FILE_SQL_ORACLE_LICENSE="server_database_oracle.sql"
	FILE_TMP_ORACLE_LICENSE="/tmp/server_database_oracle.sql"
	FILE_SQL_ORACLE_LICENSE_BASICS="server_database_oracle_basics.sql"
	FILE_TMP_ORACLE_LICENSE_BASICS="/tmp/server_database_oracle_basics.sql"
	DATABASE_ORACLE_SEPERATOR='|'

	# Da /etc/alm nur fuer root lesbar ist, Skript nach /tmp kopieren
	cp $FILE_SQL_ORACLE_LICENSE $FILE_TMP_ORACLE_LICENSE
	cp $FILE_SQL_ORACLE_LICENSE_BASICS $FILE_TMP_ORACLE_LICENSE_BASICS
	chmod 444 $FILE_TMP_ORACLE_LICENSE
	chmod 444 $FILE_TMP_ORACLE_LICENSE_BASICS

	# +ASM, -MGMTDB und * herausfiltern
	ORACLE_SID_CHECK_LIST="+ASM +APX \-MGMTDB \*"

	ORACLE_INDEX=1

	# Oracle Prozesse, was laeuft derzeit
	IFS=$'\n'
	for PMON_LINE in $ORACLE_PMON_LIST
	do
		ORACLE_HOME=""
		if [ -z "$ORACLE_PMON_LIST_WITH_ZONES" ]
		then
			ORACLE_OWNER=`echo "$PMON_LINE" | awk '{print $1}'`
			ORACLE_PROCESS=`echo "$PMON_LINE" | awk '{print $NF}'`
			ORACLE_SID=`echo $ORACLE_PROCESS | cut -d '_' -f 3-`
			ORACLE_PID=`echo "$PMON_LINE" | awk '{print $2}'`
		else
			ORACLE_OWNER=`echo "$PMON_LINE" | awk '{print $2}'`
			ORACLE_PROCESS=`echo "$PMON_LINE" | awk '{print $NF}'`
			ORACLE_SID=`echo $ORACLE_PROCESS | cut -d '_' -f 3-`
			ORACLE_PID=`echo "$PMON_LINE" | awk '{print $3}'`
		fi

		# Oracle Home ermitteln mit pwdx
		if [ -x /bin/pwdx ]
		then
			PWDX=/bin/pwdx
		fi
		if [ -x /usr/bin/pwdx ]
		then
			PWDX=/usr/bin/pwdx
		fi

		if [ -n "$PWDX" ]
		then
			ORACLE_HOME_DBS=`$PWDX $ORACLE_PID | awk '{print $NF}'`
			ORACLE_HOME=`dirname $ORACLE_HOME_DBS`
			if [ ! -f "$ORACLE_HOME/bin/sqlplus" ]
			then
				# Es ist nicht wirklich das ORACLE_HOME
				unset ORACLE_HOME_DBS
			fi
		fi
		
		if [ -z "$ORACLE_HOME_DBS" ]
		then
			# ORACLE_HOME ueber Kernel-Prozessliste ermitteln
			case "$OS_TYPE" in
				Linux)
					if [ -f /proc/$ORACLE_PID/exe ]
					then
						TEMP_ORACLE_BINARY=`ls -l /proc/$ORACLE_PID/exe | awk '{print $NF}'`
						ORACLE_BIN=`dirname $TEMP_ORACLE_BINARY`
						ORACLE_HOME=`dirname $ORACLE_BIN`
						ORACLE_HOME_DBS=$ORACLE_HOME/dbs
					else
						ORACLE_HOME_DBS=`ls -l /proc/$ORACLE_PID/cwd | awk '{print $NF}'`
					fi
					;;
				SunOS)
					ORACLE_HOME_DBS=`ls -l /proc/$ORACLE_PID/path/cwd | awk '{print $NF}'`
					;;
                                AIX)
                                        ORACLE_HOME_DBS=`ls -l /proc/$ORACLE_PID/cwd  | awk '{print $NF}'`
                                        ;;
			esac
		fi

		if [ -n "$ORACLE_HOME_DBS" ]
		then
			# ASM und MGMTDB herausfiltern
			ORACLE_SID_PASSED=1
			unset IFS
			for CHECK in $ORACLE_SID_CHECK_LIST
			do
				TEST=`echo "$ORACLE_SID" | grep "$CHECK"`
				if [ -n "$TEST"  ]
				then
						unset ORACLE_SID_PASSED
				fi
			done
                        
			if [ -n "$ORACLE_SID_PASSED" ]
                        then
                                ORACLE_HOME=`dirname $ORACLE_HOME_DBS`
                                ORACLE_SID_ARRAY[$ORACLE_INDEX]=$ORACLE_SID
                                ORACLE_OWNER_ARRAY[$ORACLE_INDEX]=$ORACLE_OWNER
                                
                                # Wenn ueber Links gestart wurde, brauchen wir das wahre ORACLE_HOME fuer die ORACLE_SID
                                # in der Datei $ORACLE_OWNER_HOME/.alm_oracle.profile hinterlegt. Format:
                                # ORACLE_SID;ORACLE_HOME
                                ORACLE_OWNER_HOME=`grep "^$ORACLE_OWNER:" /etc/passwd | cut -d ':' -f6`
                                if [ -r "$ORACLE_OWNER_HOME/.alm_oracle.profile" ]
                                then
                                        ORACLE_HOME_PROFILE=`grep -w "$ORACLE_SID" "$ORACLE_OWNER_HOME/.alm_oracle.profile" | cut -d ';' -f2`
                                        if [ -n "$ORACLE_HOME_PROFILE" ]
                                        then
                                                ORACLE_HOME=$ORACLE_HOME_PROFILE
                                        fi
                                fi
                                ORACLE_HOME_ARRAY[$ORACLE_INDEX]=$ORACLE_HOME
                                ORACLE_INDEX=$((ORACLE_INDEX+1))
                        fi
		fi
	done

	# Oracle Homes, auf Basis der oratab
	if [ -n "$ORACLE_ORATAB" ]
	then
		INSTALLATION_LIST=`grep -v ^# $ORACLE_ORATAB | grep ":"`
		IFS=$'\n'
		for INSTALLATION_LINE in $INSTALLATION_LIST
		do
			ORACLE_SID=`echo $INSTALLATION_LINE | cut -d ":" -f1`
			ORACLE_HOME=`echo $INSTALLATION_LINE | cut -d ":" -f2`

			ORACLE_SID_PASSED=1
			unset IFS
			for CHECK in $ORACLE_SID_CHECK_LIST
			do
				TEST=`echo "$ORACLE_SID" | grep "$CHECK"`
				if [ -n "$TEST"  ]
				then
					unset ORACLE_SID_PASSED
				fi
			done
			
			if [ -n "$ORACLE_SID_PASSED" ]
			then
				if [ -x "${ORACLE_HOME}/bin/sqlplus" ]
				then
					# Haben wir die SID schon mit den Oracle Homes erfasst?
					NEW_ORACLE_SID=1
					in_array "$ORACLE_SID" ORACLE_SID_ARRAY[@]
					if [ "$?" -eq 0 ]
					then
						unset NEW_ORACLE_SID
					fi
					
					# fuer ein RAC auch noch abpruefen
					for INSTANCE_NUMBER in 1 2 3 4 5 6 7 8
					do
						in_array "${ORACLE_SID}${INSTANCE_NUMBER}" ORACLE_SID_ARRAY[@]
						if [ "$?" -eq 0 ]
						then
							unset NEW_ORACLE_SID
						fi
					done
					
					if [ -n "$NEW_ORACLE_SID" ]
					then
						# Neue SID
						ORACLE_OWNER=`ls -l ${ORACLE_HOME}/bin/sqlplus | awk '{print $3}'`
						ORACLE_SID_ARRAY[$ORACLE_INDEX]=$ORACLE_SID
						ORACLE_HOME_ARRAY[$ORACLE_INDEX]=$ORACLE_HOME
						ORACLE_OWNER_ARRAY[$ORACLE_INDEX]=$ORACLE_OWNER
						ORACLE_INDEX=$((ORACLE_INDEX+1))
					fi
				fi
			fi
		done
	fi

	# Ausgabe nur, wenn wir Instanzen haben
	if [ ${#ORACLE_SID_ARRAY[@]} -gt 0 ]
	then
		ORACLE_INDEX=1
		json_array_get_index_by_module "server_oracle"
		json_module_start_level "$MACHINE_UUID"
		
		# Schleife ueber aller Instanzen
		for ORACLE_SID in ${ORACLE_SID_ARRAY[@]}
		do
			export ORACLE_SID=$ORACLE_SID
			export ORACLE_OWNER=${ORACLE_OWNER_ARRAY[$ORACLE_INDEX]}
			export ORACLE_HOME=${ORACLE_HOME_ARRAY[$ORACLE_INDEX]}
			#echo "$ORACLE_SID|$ORACLE_OWNER|$ORACLE_HOME"
			unset ORACLE_PRODUCT_ARRAY
			
			json_module_start_level "$ORACLE_SID"
			json_module_key_value "srv_oracle_machine_uuid" "$MACHINE_UUID"
			json_module_key_value "srv_oracle_hostname" "$HOSTNAME"
			json_module_key_value "srv_oracle_sid" "$ORACLE_SID"
			json_module_key_value "srv_oracle_script_version" "$SCRIPT_VERSION_DATABASE_ORACLE"
			json_module_key_value "srv_oracle_script_last_update" "$DATE_TIME"
			json_module_key_value "srv_oracle_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
			
			# Ueberpruefung, on Instanz auch wirklich lokal laeuft
			PMON_PROCESS=`ps -ef | grep -w "ora_pmon_${ORACLE_SID}" | grep -v grep`
			if [ -n "$PMON_PROCESS" ]
			then
				# Je nach Shell benoetigen wir unterschiedliche export Befehle
				EXPORT_CMD=export
				ORACLE_OWNER_SHELL=`grep $ORACLE_OWNER /etc/passwd | awk 'BEGIN {FS=":"} {print $NF}'`
				DUMMY=`echo $ORACLE_OWNER_SHELL | grep tcsh`
				if [ $? -eq 0 ]
				then
					EXPORT_CMD=set
				fi
				
				SQL_RESULT=`su - $ORACLE_OWNER -c "$EXPORT_CMD ORACLE_SID=$ORACLE_SID && $EXPORT_CMD ORACLE_HOME=$ORACLE_HOME && $ORACLE_HOME/bin/sqlplus / as sysdba @$FILE_TMP_ORACLE_LICENSE"`
				RESULT=`echo "$SQL_RESULT" | grep "^srv_oracle"`
				#echo "$SQL_RESULT"
				
				if [ -z "$RESULT" ]
				then
					SQL_RESULT=`su - $ORACLE_OWNER -c "$EXPORT_CMD ORACLE_SID=$ORACLE_SID && $EXPORT_CMD ORACLE_HOME=$ORACLE_HOME && $ORACLE_HOME/bin/sqlplus / as sysdba @$FILE_TMP_ORACLE_LICENSE_BASICS"`
					RESULT=`echo "$SQL_RESULT" | grep "^srv_oracle"`
					#echo "$SQL_RESULT"
				fi
				
				# Da srv_oracle_instance_name Primaerschluessel ist, muss der Wert geliefert werden, auch wenn die DB nicht laeuft.
				# Normalerweise kommt der Wert aus der Datenbank
				if [ -z "$RESULT" ]
				then
					json_module_key_value "srv_oracle_instance_name" "$ORACLE_SID"
				else
						# Nur wenn wir die DB abfragen konnten ist sie auch aktiv
						json_module_key_value "srv_oracle_is_active" "y"
				fi
				
				ORACLE_PRODUCT_INDEX=0
				IFS=$'\n'
				for LINE in $RESULT
				do
					KEY=`echo "$LINE" | awk -F"$DATABASE_ORACLE_SEPERATOR" '{print $1}'`
					VALUE=`echo "$LINE" | awk -F"$DATABASE_ORACLE_SEPERATOR" '{print $2}'`
					
					# auf zusaetzliche Produkte preufen
					if ( [ "$KEY" = "srv_oracle_audit_vault" ] || [ "$KEY" = "srv_oracle_exadata" ] || [ "$KEY" = "srv_oracle_goldengate" ] )
					then
						#if [ "$VALUE" == "y" ]
						#then
						#	ORACLE_PRODUCT_ARRAY[$ORACLE_PRODUCT_INDEX]=$KEY
						#	ORACLE_PRODUCT_INDEX=$((ORACLE_PRODUCT_INDEX+1))
						#fi
						unset KEY
						unset VALUE
					fi
					
					json_module_key_value "$KEY" "$VALUE"
				done
				unset IFS
				json_module_end_level
				
				# Auf weiter Prudukte pruefen
				if [ ${#ORACLE_PRODUCT_ARRAY[@]} -gt 0 ]
				then
					ORACLE_PRODUCT_INDEX=1
					#for ORACLE_PRODUCT in ${ORACLE_PRODUCT_ARRAY[@]}
					#do
					#	case "$ORACLE_PRODUCT" in
					#		'srv_oracle_audit_vault')
					#			json_module_start_level "Oracle Audit Vault"
					#			json_module_key_value "srv_oracle_product" "Oracle Audit Vault"
					#		;;
					#		
					#		'srv_oracle_exadata')
					#			json_module_start_level "Oracle Exadata"
					#			json_module_key_value "srv_oracle_product" "Oracle Exadata"
					#		;;
					#		
					#		'srv_oracle_goldengate')
					#			json_module_start_level "Oracle Golden Gate"
					#			json_module_key_value "srv_oracle_product" "Oracle Golden Gate"
					#		;;
					#	esac
					#done
					
					json_module_key_value "srv_oracle_machine_uuid" "$MACHINE_UUID"
						json_module_key_value "srv_oracle_hostname" "$HOSTNAME"
						json_module_key_value "srv_oracle_instance_name" "$ORACLE_SID"
						json_module_key_value "srv_oracle_script_version" "$SCRIPT_VERSION_DATABASE_ORACLE"
						json_module_key_value "srv_oracle_script_last_update" "$DATE_TIME"
						json_module_key_value "srv_oracle_is_active" "y"
						json_module_key_value "srv_oracle_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
					json_module_end_level
				fi
				ORACLE_INDEX=$((ORACLE_INDEX+1))
			else
				# Instanz laeuft nicht
				# Da srv_oracle_instance_name Primaerschluessel ist, muss der Wert geliefert werden, auch wenn die DB nicht laeuft.
				json_module_key_value "srv_oracle_instance_name" "$ORACLE_SID"
				json_module_end_level
			fi
		done
		json_module_end_level
	fi

	# Aufrauemen
	if [ -f "$FILE_TMP_ORACLE_LICENSE" ]
	then
		rm -f $FILE_TMP_ORACLE_LICENSE
	fi
	if [ -f "$FILE_TMP_ORACLE_LICENSE_BASICS" ]
	then
		rm -f $FILE_TMP_ORACLE_LICENSE_BASICS
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi