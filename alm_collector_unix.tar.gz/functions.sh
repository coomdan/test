#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		functions.sh									#
#	Funktion:	Funktionen fuer die ALM-Skripte							#
#													#
#########################################################################################################
#       												#
#	Versionshistorie:										#
#													#
#       12 (28.05.2019): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: Auslesen der UUID bei Solaris Zonen (Solaris 10 Zone auf Solaris 11 Host)    #
#													#
#       11 (09.01.2019): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: Auslesen UUID bei VMware (Problem mit vertauschten Stellen)                  #
#               Korrektur: UUIDs nur noch in Kleinbuchstaben						#
#                                                                                                       #
#       10 (14.12.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: VMWARE_UUID nicht ein zweites mal auslesen, wenn das erste mal geklappt hat  #
#													#
#	9 (23.05.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Neu: Funktion ceil fuer das Aufrunden (z.B. bei Core-Berechnung aus Threads)           	#
#													#
#	8 (02.02.2018): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Neu: Machine-UUID fuer Xen auslesen, wenn moeglich                                     	#
#													#
#	7 (13.10.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: IBM PowerVM durch LPAR ersetzen                                          	#
#													#
#	6 (07.07.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: Suche nach exaktem Namen in $FILE_VIRTUALIZATION_CLIENTS                    	#
#													#
#	5 (09.06.2017): Wolfgang Kurz (NSO-OSPS), w.kurz@telekom.de     				#
#	        Korrektur: PowerVM; Änderung bei UUID wegen älterer AIX Versionen                      	#
#													#
#	4 (06.04.2017): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#	        Korrektur: Solaris LDOM Abfrage, ob Primary oder Gast                                	#
#               Korrektur: fehlendes ',' in json_show_error (nach Datum)                                #
#													#
#	3 (31.08.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Abfrage der UUID des Gast-Systems bei VMware, sofern moeglich              	#
#													#
#	2 (10.05.2016): Falko Boehme (NSO-DSIO), falko.boehme@telekom.de				#
#		Neu: Speicherung der Virtualisierungsinformationen (UUID) in einer Datei        	#
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Liste von Woertern, die nie auftauchen duerfen
PROHIBITED_KEYWORD_ARRAY[0]="shutdown"
PROHIBITED_KEYWORD_ARRAY[1]="poweroff"
PROHIBITED_KEYWORD_ARRAY[2]="init "
PROHIBITED_KEYWORD_ARRAY[3]="reboot"
PROHIBITED_KEYWORD_ARRAY[4]="kill"

check_for_prohibited_keywords ()
{
	FUNCTION_FILE="functions.sh"
	FILE_LIST=`ls -1a $ALM_DIR`
	for FILE in $FILE_LIST
	do
		if [ "$FILE" != "." ] && [ "$FILE" != ".." ]
		then
			# Suche nach Variable PROHIBITED KEYWORD LIST
			DUMMY=`grep PROHIBITED_KEYWORD_ARRAY $FILE | wc -l`
			if [ "$FILE" = "$FUNCTION_FILE" ]
			then
				if [ $DUMMY -gt 8 ]
				then
					echo "PROHIBITED KEYWORD LIST was found $DUMMY times in file '$FILE'. Aborting"
					script_stop 1
				fi
			else
				if [ $DUMMY -gt 0 ]
				then
					echo "PROHIBITED KEYWORD LIST is defined in file '$FILE'. Aborting"
					script_stop 1
				fi
			fi
			
			# Suche nach Inhalt aus PROHIBITED KEYWORD LIST
			for KEYWORD in "${PROHIBITED_KEYWORD_ARRAY[@]}"
			do
				DUMMY=`grep "$KEYWORD" $FILE | grep -v PROHIBITED_KEYWORD_ARRAY | wc -l`
				if [ $DUMMY -gt 0 ]
				then
					echo "prohibited keyword '$KEYWORD' found in $FILE. Aborting"
					script_stop 1
				fi
			done
		fi
	done
}

script_start ()
{
	if [ -f $LOCK_FILE ]
	then
		echo "Lockfile ($LOCK_FILE) exists. ALM-Collector already running. Aborting."
		exit 1
	else
		echo $$ > $LOCK_FILE
	fi
}

script_stop ()
{
        if [ -n "$JSON_OUTPUT" ]
        then
                # Ausgabe in Datei
                if [ "$OUTPUT_TO_STDOUT" -eq 1 ]
                then
		        printf "$JSON_OUTPUT"
                else
                        # alte ALM-Dateien loeschen
                        rm -f $ALM_OUTPUT_DIR/*.$ALM_EXTENSION 2>/dev/null
                        OUTPUT_FILE=$HOSTNAME.$MACHINE_UUID.$DATE.$ALM_EXTENSION
                        printf "$JSON_OUTPUT" > $ALM_OUTPUT_DIR/$OUTPUT_FILE
                fi
	fi
	RETURN_CODE=$1
	rm -f $LOCK_FILE 2>&1 > /dev/null
	exit $RETURN_CODE
}

check_uuid ()
{
        # MACHINE_UUID muss die UUID enthalten
        UUID_TEST=`echo "$MACHINE_UUID" | sed "s/$REGEX_UUID//"`
}

uuid_to_lower () {
	# MACHINE_UUID in Kleinbuchstaben wandeln
	MACHINE_UUID=`echo "$MACHINE_UUID" | tr "[:upper:]" "[:lower:]"`
}

check_and_write_machine_uuid ()
{
	# wir nehmen nur Kleinbuchstaben
	uuid_to_lower
	
        # MACHINE_UUID muss die UUID enthalten
        check_uuid
        if [ -z "$UUID_TEST" ]
	then
		mkdir -p $DIR_ASSET
		echo $MACHINE_UUID > $FILE_MACHINE_UUID
	        chmod 444 $FILE_MACHINE_UUID
        else
                echo "wrong UUID format '$MACHINE_UUID'. Aborting"
		script_stop 3
	fi
}

get_machine_uuid ()
{
	if [ ! -d "$DIR_ASSET" ]
	then
		mkdir -p $DIR_ASSET
		chmod 644 $DIR_ASSET
	else
		chmod 644 $DIR_ASSET
	fi

	if [ -r "$FILE_MACHINE_UUID" ]
	then
		MACHINE_UUID=`cat $FILE_MACHINE_UUID`
		
		# Sollte die UUID noch Grossbuchstaben enthalten muss sie umgewandelt werden und neu geschrieben werden
		MACHINE_UUID_ORG=$MACHINE_UUID
		uuid_to_lower $MACHINE_UUID
		if [ "$MACHINE_UUID" != "$MACHINE_UUID_ORG" ]
		then
			check_and_write_machine_uuid
		fi
	fi
	
	if [ -z "$VIRTUALIZATION_TECHNOLOGY" ]
	then
		# Keine Virtualisierung, UUID bei Bedarf generieren
		if [ -z "$MACHINE_UUID" ]
		then
			gen_uuid
			if [ -n "$UUID" ]
			then
					MACHINE_UUID=$UUID
					if [ -n "$MACHINE_UUID" ]
					then
					        check_and_write_machine_uuid
					fi
			else
					echo "File $FILE_MACHINE_UUID does not exists and no possibility found to generate an UUID."
					echo "Please generate an UUID for this OS and write it into $FILE_MACHINE_UUID"
					echo "Aborting"
					script_stop 2
			fi
		fi
	else
		# Virtualisierung, UUID uebernehmen, sofern moeglich
		case "$VIRTUALIZATION_TECHNOLOGY" in
			'VMware')
			        # Mit vertauschten Stellen bei VMware aufpassen
			        if [ -r /sys/devices/virtual/dmi/id/product_serial ]
				then
					TMP_UUID_STRING=`cat /sys/devices/virtual/dmi/id/product_serial | sed 's/ //g' | cut -d '-' -f2-3 | sed 's/-//g'`
					VMWARE_UUID_TMP1=`echo $TMP_UUID_STRING | awk '{print substr($1,0,8)}'`
					VMWARE_UUID_TMP2=`echo $TMP_UUID_STRING | awk '{print substr($1,9,4)}'`
					VMWARE_UUID_TMP3=`echo $TMP_UUID_STRING | awk '{print substr($1,13,4)}'`
					VMWARE_UUID_TMP4=`echo $TMP_UUID_STRING | awk '{print substr($1,17,4)}'`
					VMWARE_UUID_TMP5=`echo $TMP_UUID_STRING | awk '{print substr($1,21)}'`
					VMWARE_UUID_TMP=${VMWARE_UUID_TMP1}-${VMWARE_UUID_TMP2}-${VMWARE_UUID_TMP3}-${VMWARE_UUID_TMP4}-${VMWARE_UUID_TMP5}
					VMWARE_UUID=`echo $VMWARE_UUID_TMP | tr "[:upper:]" "[:lower:]"`
					if [ -n "$MACHINE_UUID" ]
					then
						## Machine UUID vorhanden, vergleichen
						if [ "$MACHINE_UUID" != "$VMWARE_UUID" ]
						then
							echo "MACHINE_UUID ($MACHINE_UUID) differs from VMWARE_UUID ($VMWARE_UUID). Aborting"
							script_stop 3
						fi
					else
						# Machine UUID ablegen
						MACHINE_UUID=$VMWARE_UUID
						check_and_write_machine_uuid
					fi
				fi
				
				if [ -z "$VMWARE_UUID" ] && [ -r /sys/class/dmi/id/product_uuid ]
				then
					VMWARE_UUID=`cat /sys/class/dmi/id/product_uuid | tr "[:upper:]" "[:lower:]"`
					if [ -n "$MACHINE_UUID" ]
					then
						## Machine UUID vorhanden, vergleichen
						if [ "$MACHINE_UUID" != "$VMWARE_UUID" ]
						then
							echo "MACHINE_UUID ($MACHINE_UUID) differs from VMWARE_UUID ($VMWARE_UUID). Aborting"
							script_stop 3
						fi
					else
						# Machine UUID ablegen
						MACHINE_UUID=$VMWARE_UUID
						check_and_write_machine_uuid
					fi
				fi
				
				if [ -z "$VMWARE_UUID" ] && [ -x /usr/sbin/dmidecode ]
				then
					VMWARE_UUID=`/usr/sbin/dmidecode -t system | grep UUID| awk '{print $NF}' | tr "[:upper:]" "[:lower:]"`
					if [ -n "$MACHINE_UUID" ]
					then
						## Machine UUID vorhanden, vergleichen
						if [ "$MACHINE_UUID" != "$VMWARE_UUID" ]
						then
							echo "MACHINE_UUID ($MACHINE_UUID) differs from VMWARE_UUID ($VMWARE_UUID). Aborting"
							script_stop 3
						fi
					else
						# Machine UUID ablegen
						MACHINE_UUID=$VMWARE_UUID
						check_and_write_machine_uuid
					fi
				fi

				if [ -z "$MACHINE_UUID" ]
				then
				        # Fehlermeldung als JSON ausgeben, damit es auf dem Lizenzmaster ankommt
					json_show_error "$FILE_MACHINE_UUID not found. Please copy the UUID for your VCenter" "Ask your VCenter-admin to provide your UUID for the virtual machine"
				fi
				;;
				
			'Solaris Zones')
				ZONE_UUID=`zoneadm list -p | cut -d ':' -f5 | tr "[:upper:]" "[:lower:]"`
				if [ -n "$ZONE_UUID" ] && [ -z "$MACHINE_UUID" ]
				then
					# Machine UUID ablegen
					MACHINE_UUID=$ZONE_UUID
					check_and_write_machine_uuid
				fi
				
				if [ -z "$ZONE_UUID" ] && [ -n "$MACHINE_UUID" ]
				then
					# ZONE_UUID kann nicht abgefragt werden (z.B. Solaris 10 Zone auf Solaris 11 Host)
					ZONE_UUID=$MACHINE_UUID
				fi
				
				if [ -z "$ZONE_UUID" ] && [ -z "$MACHINE_UUID" ]
				then
					json_show_error "$FILE_MACHINE_UUID not found. Please copy the UUID for your zone from the global zone" "root@global_zone> cat $FILE_VIRTUALIZATION_CLIENTS"
				else
					## Machine UUID vorhanden, vergleichen
					if [ "$MACHINE_UUID" != "$ZONE_UUID" ]
					then
						echo "MACHINE_UUID ($MACHINE_UUID) differs from ZONE_UUID ($ZONE_UUID). Aborting"
						script_stop 3
					fi
				fi
				;;
			
			'Solaris LDOM')
				if [ -z "$MACHINE_UUID" ] 
				then
					if [ "$LDOM_IS_CONTROL_DOMAIN" = "true" ]
					then
					        # Machine-UUID in der Primary generieren
						gen_uuid
						if [ -n "$UUID" ]
						then
							MACHINE_UUID=$UUID
							check_and_write_machine_uuid
						else
							echo "File $FILE_MACHINE_UUID does not exists and no possibility found to generate an UUID."
							echo "Please generate an UUID for this OS and write it into $FILE_MACHINE_UUID"
							echo "Aborting"
							script_stop 2
						fi
					else
					        # MACHINE_UUID muss vorgegeben werden aus der Primary, wenn es ein Gast-LDOM ist
					        # Fehlermeldung als JSON ausgeben, damit es auf dem Lizenzmaster ankommt
						json_show_error "$FILE_MACHINE_UUID not found. Please copy the UUID for your LDOM from the Primary LDOM" "root@primary_ldom> cat $FILE_VIRTUALIZATION_CLIENTS"
					fi
				fi
				;;
				
			'Xen')
        		        if [ -x /usr/sbin/dmidecode ]
                                then
                                        MACHINE_UUID=`/usr/sbin/dmidecode -s system-serial-number | tr "[:upper:]" "[:lower:]"`
                                else
                                        # Fehlermeldung als JSON ausgeben, damit es auf dem Lizenzmaster ankommt
                                        json_show_error "$FILE_MACHINE_UUID not found. Please copy the UUID for your Xen Server to the VM" "root@xen_server> cat $FILE_VIRTUALIZATION_CLIENTS"
                                fi
                                ;;
			        
			'LPAR')
				AIX_UUID=`lsattr -El sys0 | grep os_uuid | awk '{ print$2 }' | tr "[:upper:]" "[:lower:]"`
                                if [ -n "$MACHINE_UUID" ] && [ -n "$AIX_UUID" ]
                                then
                                        ## Machine UUID vorhanden und AIX_UUID nicht null, vergleichen
                                        if [ "$MACHINE_UUID" != "$AIX_UUID" ]
                                        then
                                                echo "MACHINE_UUID ($MACHINE_UUID) differs from AIX_UUID ($AIX_UUID). Aborting"
                                                script_stop 3
                                        fi
                                else
                                        ## echo "AIX_UUID oder MACHINE_UUID   NICHT da!"
                                        if [ -n "$MACHINE_UUID" ]
                                        then
                                                ## Machin UUID ist da
                                                # Machine UUID ablegen
                                                check_and_write_machine_uuid
                                        elif [ -n "$AIX_UUID" ]
                                        then
                                                ## AIX_UUID ist da
                                                MACHINE_UUID=$AIX_UUID
                                                check_and_write_machine_uuid
                                        elif [ -z "$MACHINE_UUID" ] && [ -z "$AIX_UUID" ]
                                        then
                                                ## weder AIX_UUID noch MACHINE_UUID sind vorhanden, neu generieren
                                                gen_uuid
                                                MACHINE_UUID=$UUID
                                                check_and_write_machine_uuid
                                        fi
                                fi
				;;
		esac
	fi
}

gen_uuid () {
	if [ -x "$UUID_BINARY" ]
	then
		UUID=`$UUID_BINARY | tr "[:upper:]" "[:lower:]"`
	elif [ -x "$PYTHON_BINARY" ]
	then
		UUID=`$PYTHON_BINARY uuidgen.py | tr "[:upper:]" "[:lower:]"`
	elif [ -x "$WGET_BINARY" ]
	then
	        UUID=`$WGET_BINARY -q --no-check-certificate -O - $UUID_URL | tr "[:upper:]" "[:lower:]"`
	elif [ -x "$CURL_BINARY" ]
	then
	        UUID=`$CURL_BINARY -k $UUID_URL | tr "[:upper:]" "[:lower:]"`
	fi
}

get_virt_from_file ()
{
        VIRT_CLIENT_NAME=$1
        VIRT_FOUND=""
        if [ -r "$FILE_VIRTUALIZATION_CLIENTS" ]
        then
                # Nach dem exaktem Name suchen
                VIRT_CLIENT_ROW=`grep -w "$VIRT_CLIENT_NAME" $FILE_VIRTUALIZATION_CLIENTS`
		if [ -n "$VIRT_CLIENT_ROW" ]
		then
			VIRT_FOUND=true
			VIRT_CLIENT_TECH=`echo "$VIRT_CLIENT_ROW" | cut -d "$VIRT_CLIENT_SEPERATOR" -f1`
			VIRT_CLIENT_UUID=`echo "$VIRT_CLIENT_ROW" | cut -d "$VIRT_CLIENT_SEPERATOR" -f3`
		fi
	fi
}

push_virt_to_file ()
{
	VIRT_CLIENT_TECH=$1
	VIRT_CLIENT_NAME=$2
	VIRT_CLIENT_UUID=$3
	
	#echo "VIRT_CLIENT_TECH: $VIRT_CLIENT_TECH"
	#echo "VIRT_CLIENT_NAME: $VIRT_CLIENT_NAME"
	#echo "VIRT_CLIENT_UUID: $VIRT_CLIENT_UUID"
	
	if [ -n "$VIRT_CLIENT_TECH" ] && [ -n "$VIRT_CLIENT_NAME" ] && [ -n "$VIRT_CLIENT_UUID" ]
	then
		if [ -r "$FILE_VIRTUALIZATION_CLIENTS" ]
		then
			get_virt_from_file "$VIRT_CLIENT_NAME"
			if [ -z "$VIRT_FOUND" ]
			then
				# Neuer Eintrag
				echo "${VIRT_CLIENT_TECH}${VIRT_CLIENT_SEPERATOR}${VIRT_CLIENT_NAME}${VIRT_CLIENT_SEPERATOR}${VIRT_CLIENT_UUID}" >> $FILE_VIRTUALIZATION_CLIENTS
			fi
		else
			# Neuer Eintrag
			echo "${VIRT_CLIENT_TECH}${VIRT_CLIENT_SEPERATOR}${VIRT_CLIENT_NAME}${VIRT_CLIENT_SEPERATOR}${VIRT_CLIENT_UUID}" >> $FILE_VIRTUALIZATION_CLIENTS
		fi
	else
		echo "Error in push_virt_to_file"
		script_stop 3
	fi
}

in_array ()
{
	STRING=$1
	ARRAY=("${!2}")
	RETURN=1
	for ELEMENT in ${ARRAY[@]}
	do
		if [ "$STRING" = "$ELEMENT" ]
		then
			RETURN=0
		fi
	done
	return $RETURN
}

json_start ()
{
	JSON_OUTPUT=${JSON_OUTPUT}"{\n"
}

json_end ()
{
	# Letzten Zeilenumbruch und Komma entfernen
	JSON_OUTPUT=${JSON_OUTPUT%???}"\n"	
	JSON_OUTPUT=${JSON_OUTPUT}"}\n"
}

json_array_get_index_by_module ()
{
	MODUL=$1
	#for IND in "${!JSON_MODULE_ARRAY[@]}"	# Das Ausrufezeichen ist fuer die Keys statt Werte
	CNT=${#JSON_MODULE_ARRAY[@]}
	for (( IND=0; IND<$CNT; IND++ ))
	do
		if [ "${JSON_MODULE_ARRAY[$IND]}" = "$MODUL" ]
		then
			INDEX=$IND
		fi
	done
}

json_module_level_format ()
{
	i=1
	if [ -z "${JSON_LEVEL_ARRAY[$INDEX]}" ]
	then
		JSON_LEVEL_ARRAY[$INDEX]=1
	fi
	while [ "$i" -le "${JSON_LEVEL_ARRAY[$INDEX]}" ]
	do
		JSON_OUTPUT_ARRAY[$INDEX]="${JSON_OUTPUT_ARRAY[$INDEX]}${JSON_LEVEL_BLANKS}"
		i=$(($i + 1))
	done
}

json_module_start_level ()
{
	JSON_LEVEL_NAME=$1
	json_module_level_format
	JSON_OUTPUT_ARRAY[$INDEX]="${JSON_OUTPUT_ARRAY[$INDEX]}\"${JSON_LEVEL_NAME}\": {\n"
	JSON_LEVEL_ARRAY[$INDEX]=$((JSON_LEVEL_ARRAY[$INDEX]+1))
}

json_module_end_level ()
{
	# Letzten Zeilenumbruch und Komma entfernen
	if [ -z "$1" ]
	then
		# normales Modul
		JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]%???}"\n"
	else
		# Haupt-Modul
		JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]%?}"\n"
	fi
	JSON_LEVEL_ARRAY[$INDEX]=$((JSON_LEVEL_ARRAY[$INDEX]-1))
	json_module_level_format
	JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]}"}"
	json_module_next
}

json_module_next ()
{
	JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]}",\n"
}

json_module_key_value ()
{
	JSON_KEY=$1
	JSON_VALUE=$2
	# Keine leeren Werte ausgeben
	if [ -n "$JSON_VALUE" ]
	then
		json_module_level_format
		# Doppelte Anfuehrungszeichen escapen
                # da printf 2 mal genutzt wird, muessen wir etwas mehr escapen
                # Nach dem Ersetzen: " -> \\\\"
                # Nach dem 1. printf: \\\\" -> \\"
                # Nach dem 2. printf: \\" -> \"
                JSON_VALUE=`echo "$JSON_VALUE" | sed 's/"/\\\\\\\\\\\\\\\"/g'`

		# Zeilenumbruch
		ROW_COUNT=`echo "$JSON_VALUE" | wc -l`
		if [ $ROW_COUNT -eq 1 ]
		then
			JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]}'"'${JSON_KEY}'": "'${JSON_VALUE}'"'
			json_module_next
		else
			# Zeilen als Array darstellen
			JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]}'"'${JSON_KEY}'": '"[\n"
			IFS=$'\n'
			JSON_LEVEL_ARRAY[$INDEX]=$((JSON_LEVEL_ARRAY[$INDEX]+1))
			for LINE in $JSON_VALUE
			do
				json_module_level_format
				JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]}'"'${LINE}'"'
				json_module_next
			done
			JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]%???}"\n"
			JSON_LEVEL_ARRAY[$INDEX]=$((JSON_LEVEL_ARRAY[$INDEX]-1))
			json_module_level_format
			JSON_OUTPUT_ARRAY[$INDEX]=${JSON_OUTPUT_ARRAY[$INDEX]}"]"
			json_module_next
			unset IFS
		fi
	fi
}

json_show_error ()
{
        JSON_ERROR=$1
        JSON_SOLUTION=$2
        JSON_OUTPUT="{\n"
	JSON_OUTPUT=${JSON_OUTPUT}"${JSON_LEVEL_BLANKS}\"data_source\": {\n"
	JSON_OUTPUT=${JSON_OUTPUT}"${JSON_LEVEL_BLANKS}${JSON_LEVEL_BLANKS}\"hostname\": \"$HOSTNAME\",\n"
	JSON_OUTPUT=${JSON_OUTPUT}"${JSON_LEVEL_BLANKS}${JSON_LEVEL_BLANKS}\"datetime\": \"$DATE_TIME\",\n"
        JSON_OUTPUT=${JSON_OUTPUT}"${JSON_LEVEL_BLANKS}${JSON_LEVEL_BLANKS}\"collector\": \"unix\"\n"
	JSON_OUTPUT=${JSON_OUTPUT}"${JSON_LEVEL_BLANKS}},\n"
	JSON_OUTPUT=${JSON_OUTPUT}"${JSON_LEVEL_BLANKS}\"Error\": \"$JSON_ERROR\",\n"
	JSON_OUTPUT=${JSON_OUTPUT}"${JSON_LEVEL_BLANKS}\"Solution\": \"$JSON_SOLUTION\"\n"
	JSON_OUTPUT=${JSON_OUTPUT}"}\n"
	script_stop 255
}

ceil ()
{
        FLOAT=$1
        # Gibt es eine Nachkommastelle mit "."
        INTEGER=`echo $FLOAT | cut -d '.' -f1`
        DUMMY=`echo $FLOAT | grep "\."`
        if [ $? -eq 0 ]
        then
                CEIL_RESULT=$((INTEGER+1))
        else
                CEIL_RESULT=$INTEGER
        fi
}