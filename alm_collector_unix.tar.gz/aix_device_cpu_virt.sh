#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		aix_device_cpu_virt.sh								#
#	Funktion:	Abfrage der CPU unter AIX							#
#	Version:	1										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#													#
#	1 (09.11.2016): Wolfgang Kurz  (NSO-OSPS)  w.kurz@telekom.de     				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_AIX_DEVICE_CPU_VIRT='1'
	
	# CPU Daten auf jeden Fall abfragen, damit sie auch fuer die Physik zur Verfuegung stehen
	# PROC_CPUINFO=`cat /proc/cpuinfo`
	# CPU_MODEL=`echo "$PROC_CPUINFO" | grep "model name" | uniq | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
	# welcher proc existiert 
	PROC=`lsdev -Cc processor | head  -n1 | awk '{ print$1 }'`
	CPU_MODEL_ORG=`lsattr -El $PROC | grep "type" | awk '{ print$2 }'`
	# CPU_SPEED_MHZ=`echo "$PROC_CPUINFO" | grep "MHz" | sort -n | tail -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
	CPU_SPEED_HZ=`lsattr -El $PROC | grep "frequency" | awk '{ print$2 }'`
	# if [ -n "$BC_BINARY" ]
	# then
	#	CPU_SPEED_GHZ=`echo "scale=2; $CPU_SPEED_MHZ/1000" | bc`
	# fi
	CPU_SPEED_GHZ=`echo "scale=2; $CPU_SPEED_HZ/1000000000" | bc`

	# Nun CPU_MODEL zusammenbauen
	CPU_MODEL=$CPU_MODEL_ORG" @ "$CPU_SPEED_GHZ"GHz"

	# CPU_COUNT=`echo "$PROC_CPUINFO" | grep "physical id" | sort | uniq | wc -l`
	# CPU_CORES_PER_CPU=`echo "$PROC_CPUINFO" | grep "core id" | sort | uniq | wc -l`
		# CPU_THREAD_COUNT=`echo "$PROC_CPUINFO" | grep "processor" | wc -l`
	# CPU_THREADS_PER_CPU=`echo "$PROC_CPUINFO" | grep "siblings" | uniq | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
	if [ `lsattr -El $PROC | grep "smt_enabled" | awk '{ print$2 }'` == "true" ]
	then	
		CPU_THREADS_PER_CORE=`lsattr -El $PROC | grep "smt_threads" | awk '{ print$2 }'`
	#	CPU_THREAD_COUNT=$((CPU_THREADS_PER_CORE*CPU_COUNT))
	fi
	
	
	# if [ $CPU_CORES_PER_CPU -ge 1 ]
	# then
	#       CPU_CORE_COUNT=$((CPU_CORES_PER_CPU*CPU_COUNT))	
	#      CPU_THREADS_PER_CORE=$((CPU_THREADS_PER_CPU/CPU_CORES_PER_CPU))
    #  fi
	
	if [ -n "$VIRTUALIZATION_TECHNOLOGY" ]
	then
		json_array_get_index_by_module "device_cpu"
		
		# eigene CPU ausgeben
		json_module_start_level "$CPU_MODEL"
		json_module_key_value "cpu_script_version" "$SCRIPT_VERSION_AIX_DEVICE_CPU_VIRT"
		json_module_key_value "cpu_script_last_update" "$DATE_TIME"
		json_module_key_value "cpu_data_source" "$HOSTNAME"
		json_module_key_value "cpu_model" "$CPU_MODEL"
		json_module_key_value "cpu_cores_per_cpu" "$CPU_CORES_PER_CPU"
		json_module_key_value "cpu_threads_per_cpu" "$CPU_THREADS_PER_CPU"
		json_module_key_value "cpu_threads_per_core" "$CPU_THREADS_PER_CORE"
		json_module_key_value "cpu_speed_ghz" "$CPU_SPEED_GHZ"
		json_module_key_value "cpu_is_active" "y"
		json_module_end_level
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi