#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_cpu_linux.sh								#
#	Funktion:	Abfrage der CPU unter Linux							#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	9 (09.05.2019): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: Geschwindigkeit der CPU bei lscpu                                            #
#													#
#	8 (09.01.2019): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: Abfrage, ob CPU_CORES_PER_CPU leer ist                                       #
#													#
#	7 (21.12.2018): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: Anfuehrungszeichen bei 'if [ "$CPU_CORES_PER_CPU" -ge 1 ]' hinzugefuegt	#
#													#
#	6 (26.09.2018): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: CPU-Detektion in der Reihenfolge: lscpu, dmidecode, /proc/cpu		#
#													#
#	5 (11.09.2018): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: Ueberpruefen, ob CPU_MODEL gesetzt ist					#
#													#
#	4 (19.07.2018): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Neu: Mehrere Moeglichkeiten die CPU auszulesen (dmidecode, lscpu, /proc/cpu)		#
#													#
#	3 (28.06.2017): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Neu: Sonderfall Xen-Virtualisierung							#
#													#
#	2 (28.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Wegfall des Schluessels cpu_has_hyperthreading (aus cpu_threads_per_core ableitbar)     #
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_LINUX_DEVICE_CPU='9'
	
	# CPU Daten auf jeden Fall abfragen, damit sie auch fuer die Physik zur Verfuegung stehen
	if [ -x /usr/bin/lscpu ]
	then
		LSCPU=`lscpu`
		CPU_MODEL=`echo "$LSCPU" | grep "Model name" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_SPEED_MHZ=`echo "$LSCPU" | grep "CPU MHz" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_COUNT=`echo "$LSCPU" | grep "Socket" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_CORES_PER_CPU=`echo "$LSCPU" | grep "Core(s) per socket" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_THREAD_COUNT=`echo "$LSCPU" | grep "processor" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_THREADS_PER_CORE=`echo "$LSCPU" | grep "Thread(s) per core" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_THREADS_PER_CPU=$((CPU_THREADS_PER_CORE*CPU_CORES_PER_CPU))	
		CPU_CORE_COUNT=$((CPU_CORES_PER_CPU*CPU_COUNT))
	fi
	
	if  [ -z "$CPU_MODEL" ] && [ -x /usr/sbin/dmidecode ]
	then
		DMIDECODE_PROCESSOR=`/usr/sbin/dmidecode --type processor`
		CPU_MODEL=`echo "$DMIDECODE_PROCESSOR" | grep "Version" | tail -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_SPEED_MHZ=`echo "$DMIDECODE_PROCESSOR" | grep "Current Speed" | tail -1 | cut -d ':' -f2 | awk '{print $1}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_COUNT=`echo "$DMIDECODE_PROCESSOR" | grep "Version" | wc -l`
		CPU_CORES_PER_CPU=`echo "$DMIDECODE_PROCESSOR" | grep "Core Count" | tail -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_CORES_PER_CPU_ENABLED=`echo "$DMIDECODE_PROCESSOR" | grep "Core Enabled" | tail -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_THREADS_PER_CPU=`echo "$DMIDECODE_PROCESSOR" | grep "Thread Count" | tail -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		if [ -z "$CPU_MODEL" ] || [ "$CPU_MODEL" = "Unknown Processor" ] || [ "$CPU_MODEL" = "Not Specified" ]
		then
			# noch mit head statt tail versuchen
			CPU_MODEL=`echo "$DMIDECODE_PROCESSOR" | grep "Version" | head -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			CPU_SPEED_MHZ=`echo "$DMIDECODE_PROCESSOR" | grep "Current Speed" | head -1 | cut -d ':' -f2 | awk '{print $1}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
			CPU_COUNT=`echo "$DMIDECODE_PROCESSOR" | grep "Version" | wc -l`
			CPU_CORES_PER_CPU=`echo "$DMIDECODE_PROCESSOR" | grep "Core Count" | head -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			CPU_CORES_PER_CPU_ENABLED=`echo "$DMIDECODE_PROCESSOR" | grep "Core Enabled" | head -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			CPU_THREADS_PER_CPU=`echo "$DMIDECODE_PROCESSOR" | grep "Thread Count" | head -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		fi
		CPU_THREAD_COUNT=$((CPU_COUNT*CPU_THREADS_PER_CPU))
		if [ -n "$CPU_CORES_PER_CPU" ] && [ "$CPU_CORES_PER_CPU" -ge 1 ]
		then
			CPU_CORE_COUNT=$((CPU_CORES_PER_CPU*CPU_COUNT))	
			CPU_THREADS_PER_CORE=$((CPU_THREADS_PER_CPU/CPU_CORES_PER_CPU))
		fi
	fi
	
	if [ -z "$CPU_MODEL" ] || [ "$CPU_MODEL" = "Unknown Processor" ] || [ "$CPU_MODEL" = "Not Specified" ]
	then
		PROC_CPUINFO=`cat /proc/cpuinfo`
		CPU_MODEL=`echo "$PROC_CPUINFO" | grep "model name" | uniq | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_SPEED_MHZ=`echo "$PROC_CPUINFO" | grep "MHz" | sort -n | tail -1 | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		CPU_COUNT=`echo "$PROC_CPUINFO" | grep "physical id" | sort | uniq | wc -l`
		CPU_CORES_PER_CPU=`echo "$PROC_CPUINFO" | grep "core id" | sort | uniq | wc -l`
		CPU_THREAD_COUNT=`echo "$PROC_CPUINFO" | grep "processor" | wc -l`
		CPU_THREADS_PER_CPU=`echo "$PROC_CPUINFO" | grep "siblings" | uniq | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
		
		if [ "$CPU_CORES_PER_CPU" -ge 1 ]
		then
			CPU_CORE_COUNT=$((CPU_CORES_PER_CPU*CPU_COUNT))	
			CPU_THREADS_PER_CORE=$((CPU_THREADS_PER_CPU/CPU_CORES_PER_CPU))
		fi
	fi
	
	if [ -n "$BC_BINARY" ]
	then
		CPU_SPEED_GHZ=`echo "scale=2; $CPU_SPEED_MHZ/1000" | bc`
	fi
	
	
	
	# Sonderfall Xen-Virtualisierung (Haupt-OS sieht nur seine eigenen Werte unter /proc/cpuinfo, deshalb mit xl info auslesen)
	if [ -x /usr/sbin/xl ]
		then
			XL_BINARY="/usr/sbin/xl"
		fi
	if [ -n "$XL_BINARY" ]
	then
		XL_INFO=`$XL_BINARY info`
		if [ -n "$XL_INFO" ]
		then
			CPU_COUNT=`echo "$XL_INFO" | grep "nr_nodes" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			CPU_CORES_PER_CPU=`echo "$XL_INFO" | grep "cores_per_socket" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			CPU_CORE_COUNT=$((CPU_COUNT*CPU_CORES_PER_CPU))
			CPU_THREADS_PER_CORE=`echo "$XL_INFO" | grep "threads_per_core" | cut -d ':' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//'`
			CPU_THREADS_PER_CPU=$((CPU_CORES_PER_CPU*CPU_THREADS_PER_CORE))
			CPU_THREAD_COUNT=$((CPU_CORE_COUNT*CPU_THREADS_PER_CORE))
		fi
	fi
	
	if [ -z "$VIRTUALIZATION_TECHNOLOGY" ]
	then
		json_array_get_index_by_module "device_cpu"
		
		# eigene CPU ausgeben
		json_module_start_level "$CPU_MODEL"
		json_module_key_value "cpu_script_version" "$SCRIPT_VERSION_LINUX_DEVICE_CPU"
		json_module_key_value "cpu_script_last_update" "$DATE_TIME"
		json_module_key_value "cpu_data_source" "$HOSTNAME"
		json_module_key_value "cpu_model" "$CPU_MODEL"
		json_module_key_value "cpu_cores_per_cpu" "$CPU_CORES_PER_CPU"
		json_module_key_value "cpu_threads_per_cpu" "$CPU_THREADS_PER_CPU"
		json_module_key_value "cpu_threads_per_core" "$CPU_THREADS_PER_CORE"
		json_module_key_value "cpu_speed_ghz" "$CPU_SPEED_GHZ"
		json_module_key_value "cpu_is_active" "y"
		json_module_end_level
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi