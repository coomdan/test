#########################################################################################################
#                                                                                                       #
#       Projekt:        Automatisierung Lizenzmanagement (ALM)                                          #
#       Skript:         aix_device_hmc.sh                                                               #
#       Funktion:       Abfrage der CPU unter AIX                                                       #
#       Version:        1                                                                               #
#                                                                                                       #
#########################################################################################################
#                                                                                                       #
#       Versionshistorie:                                                                               #
#                                                                                                       #
#                                                                                                       #
#       1 (30.10.2017): Wolfgang Kurz  (NSO-OSBI)  w.kurz@telekom.de                                    #
#               Erste Version                                                                           #
#                                                                                                       #
#########################################################################################################



HMC='hmc7-94.nmc-m.dtag.de'
AIX_SYSTEME=${DIR_ASSET}'/hmc_systeme.txt'
FILE_PHYSICAL_AIX_ID=${DIR_ASSET}'/hmc_serial_number.txt'
FILE_PHYSICAL_AIX_ID_BACK=${DIR_ASSET}'/hmc_serial_number.back.txt'
# zum Test



# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
        SCRIPT_VERSION_AIX_DEVICE_HMC='1'
        
        # Abfragen der Server
        ssh hscroot@$HMC "lssyscfg -r sys -F name" > $AIX_SYSTEME
        
        # grep nur zum Test
        #for AIX_HW in `cat $AIX_SYSTEME | grep 3520`
        # Die ausgeschalteten Server und die beiden nim (nicht scannen)
        for AIX_HW in `cat $AIX_SYSTEME | egrep -v "OUT|NIM"`
        do
                echo "SERVER = "$AIX_HW
                # Die 1. VIO-Partitionen mit aktiver RMC-Connection nehmen
                PART_AKT=`ssh hscroot@$HMC "lssyscfg -r lpar -m $AIX_HW -F name,rmc_state" | grep '.*vio.,active' | head -n1`
                # for PART_AKT in `ssh hscroot@$HMC "lssyscfg -r lpar -m $AIX_HW -F name" | grep vio`
                #do
                echo "Partition = "$PART_AKT
                if [ -n "$PART_AKT" ]
                then 
                        #echo "Partition = "$PART
                        #AIX_VIO=`echo $PART | awk -F"-" '{ print$2 }'`
                        # ist es der erste oder einzige VIO?
                        #if [[ $AIX_VIO == "vio1" || $AIX_VIO == "vio" ]]
                        #then
                        
                        PART=`echo $PART_AKT | awk -F"," '{ print$1 }'`
                        echo "VIO = $PART"
                                                        
                        # CPU ermitteln
                        #. ./aix_device_cpu_virt.sh
                        echo "CPU wird ermittelt"
                        MAN_NAME=`echo $AIX_HW | cut -d '_' -f1`
                        echo "MAN_NAME="$MAN_NAME
                        # welcher proc existiert 
                        PROC=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"lsdev \"" | grep proc | head  -n1 | awk '{ print$1 }'`
                        echo "PROC "$PROC
                        #
                        CPU_SPEED_HZ=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"lsdev -dev $PROC -attr\"" | grep frequency | awk '{ print$2 }'`
                        echo "SPEED = "$CPU_SPEED_HZ
                        CPU_SPEED_GHZ=`echo "scale=2; $CPU_SPEED_HZ/1000000000" | bc`
                        #
                        CPU_MODEL_ORG=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"lsdev -dev $PROC -attr\"" | grep type | awk '{ print$2 }'`
                        echo "TYPE = "$CPU_MODEL_ORG
                        # Nun CPU_MODEL zusammenbauen
                        CPU_MODEL=$CPU_MODEL_ORG" @ "$CPU_SPEED_GHZ"GHz"
                        echo "Modell = "$CPU_MODEL
                        #
                        # CPU_THREADS_PER_CORE
                        if [ `ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"lsdev -dev $PROC -attr\"" | grep smt_enabled | awk '{ print$2 }'` == "true" ]
                        then
                                CPU_THREADS_PER_CORE=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"lsdev -dev $PROC -attr\"" | grep smt_threads | awk '{ print$2 }'`
                                echo "CPU_THREADS_PER_CORE = "$CPU_THREADS_PER_CORE
                        fi      
                        
                        
                        # Physik                
                        # SN abfragen
                        PHYSICAL_ID_AIX=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"lsdev -dev sys0 -attr \""| grep systemid | awk '{ print$2 }'`
                        
                        if [ -r $FILE_PHYSICAL_AIX_ID ]
                        then
                                #if [ -n  `grep $MAN_NAME $FILE_PHYSICAL_AIX_ID`  ]
                                #then           
                                        PHYSICAL_ID=`grep $MAN_NAME $FILE_PHYSICAL_AIX_ID | awk ' FS=":" { print$2 }'`
                                        MACHINE_UUID=`grep $MAN_NAME $FILE_PHYSICAL_AIX_ID | awk ' FS=":" { print$3 }'`
                                        echo "$MAN_NAME mit SN: $PHYSICAL_ID und UUID: $MACHINE_UUID"
                                        
                                        # Seriennummer überprüfen
                                        if [ -z $PHYSICAL_ID ]
                                        then
                                                echo "Physical ID ist leer; ggf feht auch der gesamte Eintrag"
                                                PHYSICAL_ID=$PHYSICAL_ID_AIX
                                                echo "WIRK   "$FILE_PHYSICAL_AIX_ID
                                                echo "BACK   "$FILE_PHYSICAL_AIX_ID_BACK
                                                grep -v $MAN_NAME $FILE_PHYSICAL_AIX_ID > $FILE_PHYSICAL_AIX_ID_BACK
                                                cat $FILE_PHYSICAL_AIX_ID_BACK > $FILE_PHYSICAL_AIX_ID
                                                echo "es wird geschrieben:$MAN_NAME:$PHYSICAL_ID"
                                                echo "$MAN_NAME:$PHYSICAL_ID" >> $FILE_PHYSICAL_AIX_ID
                                                chmod 444  $FILE_PHYSICAL_AIX_ID
                                                cat $FILE_PHYSICAL_AIX_ID
                                        else
                                                echo "SN ist da"        
                                                
                                        fi
                                        
                                        # phys_machine_uuid überprüfen
                                        MACHINE_UUID=`grep $MAN_NAME $FILE_PHYSICAL_AIX_ID | awk ' FS=":" { print$3 }'`
                                        if [ -z $MACHINE_UUID ]
                                        then    
                                                echo " MACHINE_UUID ist leer"
                                                gen_uuid
                                                if [ -n "$UUID" ]
                                                then
                                                        MACHINE_UUID=$UUID
                                                        if [ -n "$MACHINE_UUID" ]
                                                        then
                                                                #       check_and_write_machine_uuid
                                                                echo "UUID ist $MACHINE_UUID" 
                                                                # speichern
                                                                grep -v $MAN_NAME $FILE_PHYSICAL_AIX_ID > $FILE_PHYSICAL_AIX_ID_BACK
                                                                cat $FILE_PHYSICAL_AIX_ID_BACK > $FILE_PHYSICAL_AIX_ID
                                                                echo "es wird geschrieben:$MAN_NAME:$PHYSICAL_ID:$MACHINE_UUID"
                                                                echo "$MAN_NAME:$PHYSICAL_ID:$MACHINE_UUID" >> $FILE_PHYSICAL_AIX_ID
                                                                chmod 444  $FILE_PHYSICAL_AIX_ID
                                                                cat $FILE_PHYSICAL_AIX_ID
                                                        else
                                                                echo "UUID ist da"
                                                        fi
                                                else
                                                        echo "File $FILE_MACHINE_UUID does not exists and no possibility found to generate an UUID."
                                                        echo "Please generate an UUID for this OS and write it into $FILE_MACHINE_UUID"
                                                        echo "Aborting"
                                                        script_stop 2
                                                fi                                              
                                                                                                                        
                                        fi
                                        
                                        #CPU_CORE_COUNT
                                        #CPU_CORE_COUNT=`lparstat -i | grep "Active Physical CPUs in system" | awk -F ":" '{ print$2 }' | tr -d ' '`
                                        CPU_CORE_COUNT=`ssh hscroot@$HMC "lshwres -r proc --level sys -m $AIX_HW -F configurable_sys_proc_units" | awk ' FS="." { print$1
                                        }'` 
                                        
                                        #CPU_THREAD_COUNT"
                                        CPU_THREAD_COUNT=$((CPU_THREADS_PER_CORE*CPU_CORE_COUNT))
                                        echo "CPU_THREAD_COUNT = $CPU_THREAD_COUNT"             
                                        
                                        # Memory 
                                        MEMORY_MB=`ssh hscroot@$HMC "lshwres -r mem --level sys -m $AIX_HW -F configurable_sys_mem"`    
                                        
                                        #PHYS_SERVER_MODEL=`lsattr -El sys0 | grep modelname | awk '{ print$2 }'`
                                        PHYS_SERVER_MODEL=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"lsdev -dev sys0 -attr \""| grep modelname | awk '{ print$2 }'`
                                        
                                        PHYS_RELATION='Host for virt. machines' 
                                        

                                        ## SYSTEM
                                        SYS_OS_TYPE='AIX'
                                        SYS_OS_NAME='IOS'
                                        #OS_VERSION=`/usr/ios/cli/ioscli ioslevel`
                                        IOS_LEVEL=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"ioslevel\""`
                                        #if [ -n $IOS_LEVEL ]
                                        #then
                                        #       OS_VERSION="IOS, $IOS_LEVEL"
                                        #fi
                                                                                
                                        #OS_SUBVERSION=`cat /usr/ios/cli/FPLEVEL.txt`
                                        #if [ -n IOS_LEVEL=`ssh hscroot@$HMC "viosvrcmd -m $AIX_HW -p $PART -c \"ioslevel\""` ]
                                        #then
                                        #       OS_VERSION="IOS, $IOS_LEVEL"
                                        #fi
                                        
                                        
                                #else
                                #       # Fehlermeldung als JSON ausgeben, damit es auf dem Lizenzmaster ankommt
                                #       json_show_error "Server hat"
                                 #fi
                                
                                
                        
                        
                        else
                                echo "Datei $FILE_PHYSICAL_AIX_ID fehlt!"
                        fi              
                        
                        
                        json_array_get_index_by_module "device_system"
        
                        json_module_start_level "$MACHINE_UUID"
                        json_module_key_value "sys_script_version" "$SCRIPT_VERSION_AIX_DEVICE_HMC"
                        json_module_key_value "sys_script_last_update" "$DATE_TIME"
                        json_module_key_value "sys_hostname" "$MAN_NAME"
                        json_module_key_value "sys_machine_uuid" "$MACHINE_UUID"
                        json_module_key_value "sys_is_active" "y"
                        json_module_key_value "sys_fqdn" 
                        json_module_key_value "sys_os_type" "$SYS_OS_TYPE"
                        json_module_key_value "sys_os_name" "$SYS_OS_NAME"
                        json_module_key_value "sys_os_version" "$IOS_LEVEL"
                        json_module_key_value "sys_os_subversion" "$OS_SUBVERSION"
                        json_module_end_level
                        
                        
                        
        
        
        


                        json_array_get_index_by_module "device_physical"
                        
                        json_module_start_level "$PHYSICAL_ID"
                        json_module_key_value "phys_script_version" "$SCRIPT_VERSION_AIX_DEVICE_HMC"
                        json_module_key_value "phys_script_last_update" "$DATE_TIME"
                        json_module_key_value "phys_device_id" "$PHYSICAL_ID"
                        json_module_key_value "phys_hostname" "$MAN_NAME"
                        #json_module_key_value "cpu_data_source" "$MAN_NAME"
                        json_module_key_value "phys_machine_uuid" "$MACHINE_UUID"
                        json_module_key_value "phys_relation"  "$PHYS_RELATION"
                        json_module_key_value "phys_os" "$OS_TYPE"
                        json_module_key_value "phys_server_model" "$PHYS_SERVER_MODEL"
                        json_module_key_value "phys_cpu_model" "$CPU_MODEL"
                        json_module_key_value "phys_cpu_count" "$CPU_COUNT"
                        json_module_key_value "phys_core_count" "$CPU_CORE_COUNT"
                        json_module_key_value "phys_thread_count" "$CPU_THREAD_COUNT"
                        json_module_key_value "phys_is_active" "y"
                        json_module_key_value "phys_fqdn" 
                        json_module_key_value "phys_memory_mb" "$MEMORY_MB"
                        json_module_end_level
                        
                        
                        
                        
                        json_array_get_index_by_module "device_cpu"
                        
                        # eigene CPU ausgeben
                        json_module_start_level "$CPU_MODEL"
                        json_module_key_value "cpu_script_version" "$SCRIPT_VERSION_AIX_DEVICE_HMC"
                        json_module_key_value "cpu_script_last_update" "$DATE_TIME"
                        #json_module_key_value "cpu_data_source" "$HOSTNAME"
                        json_module_key_value "cpu_data_source" "$MAN_NAME"
                        json_module_key_value "cpu_model" "$CPU_MODEL"
                        json_module_key_value "cpu_cores_per_cpu" "$CPU_CORES_PER_CPU"
                        json_module_key_value "cpu_threads_per_cpu" "$CPU_THREADS_PER_CPU"
                        json_module_key_value "cpu_threads_per_core" "$CPU_THREADS_PER_CORE"
                        json_module_key_value "cpu_speed_ghz" "$CPU_SPEED_GHZ"
                        json_module_key_value "cpu_is_active" "y"
                        json_module_end_level
                        
                else
                        echo "kein VIO gefunden!"       
        
                fi
                 
        done

else
        echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi