#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		aix_device_phys_for_virt.sh							#
#	Funktion:	Zuordnung der virtuellen Server zu dem physikalischen Server unter Linux	#
#	Version:	3										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#                                                                                                       #
#	3 (13.10.2017): Wolfgang Kurz (NSO-OSBI), w.kurz@telekom.de     				#
#		Änderung: LPAR als Ersatz für PowerVM                                                   #
#                                                                                                       #
#	2 (14.06.2017): Wolfgang Kurz (NSO-OSPS), w.kurz@telekom.de     				#
#		Änderung: Sonderbehandlung hostname entfernt                                            #
#                                                                                                       #
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_AIX_DEVICE_PHYS_FOR_VIRT='3'
	
			
	#IBM PowerVM bzw. LPAR
	if [ -r $FILE_PHYSICAL_ID ]
	then
		PHYSICAL_ID=`cat $FILE_PHYSICAL_ID`
	else
		PHYSICAL_ID=`lsattr -El sys0 | grep systemid | awk '{ print$2 }'`
		if [ -n "$PHYSICAL_ID" ]
			then
			echo "$PHYSICAL_ID" > $FILE_PHYSICAL_ID
			chmod 444 $FILE_PHYSICAL_ID
		fi
	fi		
			
			
	# geht nicht, manuelle Erfassung
	#CPU_COUNT"
	
	#CPU_CORE_COUNT
	#CPU_CORE_COUNT=`lsdev|grep proc|wc -l`
	CPU_CORE_COUNT=`lparstat -i | grep "Active Physical CPUs in system" | awk -F ":" '{ print$2 }' | tr -d ' '`
		
	#CPU_THREAD_COUNT"
	PROC=`lsdev -Cc processor | head  -n1 | awk '{ print$1 }'`
	if [ `lsattr -El $PROC | grep "smt_enabled" | awk '{ print$2 }'` == "true" ]
		then	
			CPU_THREADS_PER_CORE=`lsattr -El $PROC | grep "smt_threads" | awk '{ print$2 }'`
			CPU_THREAD_COUNT=$((CPU_THREADS_PER_CORE*CPU_CORE_COUNT))
	fi
	
	
	PHYS_SERVER_MODEL=`lsattr -El sys0 | grep modelname | awk '{ print$2 }'`
		
	
	PHYS_RELATION='Host for virt. machines'
	#PHYS_VIRTUALIZATION='powervm'		
	
	# geht nicht, 
	#MEMORY_KB=`lsattr -El sys0 | grep realmem | awk '{ print$2 }'`
        #MEMORY_MB=$((MEMORY_KB/1024))	
	
	
	#
	IOS_LEVEL=`/usr/ios/cli/ioscli ioslevel`
	OS_TYPE="IOS, $IOS_LEVEL"
	
	
	# hostname für die Physik anpassen, wenn ppc...
	#if [[ `hostname`  == "ppc"* ]]
	#	then
	#	PHYS_HOSTNAME=`hostname | sed 's/ppc/MAN/' | awk -F'-' '{ print$1 }'`
	#fi
	
	# eigene Physik ausgeben
	json_array_get_index_by_module "device_physical"
			
	json_module_start_level "$PHYSICAL_ID"
	json_module_key_value "phys_script_version" "$SCRIPT_VERSION_AIX_DEVICE_PHYS_FOR_VIRT"
	json_module_key_value "phys_script_last_update" "$DATE_TIME"
	json_module_key_value "phys_device_id" "$PHYSICAL_ID"
	json_module_key_value "phys_hostname" "$HOSTNAME"
	json_module_key_value "phys_machine_uuid" "$MACHINE_UUID"
	json_module_key_value "phys_relation"  "$PHYS_RELATION"
	json_module_key_value "phys_os" "$OS_TYPE"
	json_module_key_value "phys_server_model" "$PHYS_SERVER_MODEL"
	json_module_key_value "phys_cpu_model" "$CPU_MODEL"
	json_module_key_value "phys_cpu_count" "$CPU_COUNT"
	json_module_key_value "phys_core_count" "$CPU_CORE_COUNT"
	json_module_key_value "phys_thread_count" "$CPU_THREAD_COUNT"
	json_module_key_value "phys_is_active" "y"
	json_module_key_value "phys_fqdn" "$FQDN"
	json_module_key_value "phys_memory_mb" 
	json_module_end_level
			

else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi