#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		sun_server.sh									#
#	Funktion:	Abfrage von SUN Servern								#
#	Version:	0.1										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	0.1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_SERVER_SOLARIS='1'
	
	json_array_get_index_by_module "server_solaris"
	json_module_start_level "$MACHINE_UUID"
	
	# Betriebssystem
	SOLARIS_INSTANCE_NAME="Solaris OS"
	SOLARIS_PRODUCT='SUN Solaris'	
	if [ -r /etc/release ]
	then
		SOLARIS_VERSION=`cat /etc/release | head -1 | sed 's/^[ \t]*//;s/[ \t]*$//'`
	else
		SOLARIS_VERSION=`uname -r`
	fi
	
	json_module_start_level "$SOLARIS_INSTANCE_NAME"
	json_module_key_value "srv_solaris_machine_uuid" "$MACHINE_UUID"
	json_module_key_value "srv_solaris_hostname" "$HOSTNAME"
	json_module_key_value "srv_solaris_instance_name" "$SOLARIS_INSTANCE_NAME"
	json_module_key_value "srv_solaris_product" "$SOLARIS_PRODUCT"
	json_module_key_value "srv_solaris_version" "$SOLARIS_VERSION"
	json_module_key_value "srv_solaris_script_version" "$SCRIPT_VERSION_SERVER_SOLARIS"
	json_module_key_value "srv_solaris_script_last_update" "$DATE_TIME"
	json_module_key_value "srv_solaris_is_active" "y"
	json_module_key_value "srv_solaris_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
	json_module_end_level
		
	# Auf Cluster Prüfen
	if [ -x /usr/cluster/bin/clnode ]
	then
		CLUSTER_VERSION=`/usr/cluster/bin/clnode show-rev`
		if [ -n "$CLUSTER_VERSION" ]
		then
			SOLARIS_INSTANCE_NAME="Solaris Cluster"
			SOLARIS_PRODUCT='SUN Solaris Cluster'
			
			json_module_start_level "$SOLARIS_INSTANCE_NAME"
			json_module_key_value "srv_solaris_machine_uuid" "$MACHINE_UUID"
			json_module_key_value "srv_solaris_hostname" "$HOSTNAME"
			json_module_key_value "srv_solaris_instance_name" "$SOLARIS_INSTANCE_NAME"
			json_module_key_value "srv_solaris_product" "$SOLARIS_PRODUCT"
			json_module_key_value "srv_solaris_version" "$CLUSTER_VERSION"
			json_module_key_value "srv_solaris_script_version" "$SCRIPT_VERSION_SERVER_SOLARIS"
			json_module_key_value "srv_solaris_script_last_update" "$DATE_TIME"
			json_module_key_value "srv_solaris_is_active" "y"
			json_module_key_value "srv_solaris_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
			json_module_end_level
		fi
	fi
		
	json_module_end_level
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi