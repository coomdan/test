#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		aix_device_virtualization.sh							#
#	Funktion:	Abfrage der Virtualisierung unter AIX						#
#	Version:	3										#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	1 (16.11.2016): Wolfgang Kurz, NSO-OSPS w.kurz@telekom.de				        #
#		Erste Version				                                                #
#                                                                                                       #
#	2 (12.7.2017): Wolfgang Kurz, NSO-OSPS w.kurz@telekom.de				        #
#		Für die LPAR vio1 bzw vio wird kein Virtualisierungslayer erzeugt, weil dies            #
#               die Physik darstellt.                                                                   #
#                                                                                                       #
#	3 (13.10.2017): Wolfgang Kurz, NSO-OSBI w.kurz@telekom.de				        #
#		PowerVM wird durch LPAR ersetzt		                                                #
#                                                                                                       #
#	4 (13.11.2017): Wolfgang Kurz, NSO-OSBI w.kurz@telekom.de				        #
#		Abfrage der Hardware für virtualisierte systeme immer durch HMC                         #
#                                                                                                       #
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_AIX_DEVICE_VIRTUALIZATION='4'
	

	# Memory
	#VIRT_MEMORY_MB=`prtconf 2>/dev/null | grep Memory | cut -d ':' -f2 | awk '{print $1}'`
	VIRT_MEMORY_MB=`lparstat -i | grep "Online Memory" | awk '{ print$4 }'`

        #virt_devcie_id
	PHYSICAL_ID=`lsattr -El sys0 | grep systemid | awk '{ print$2 }'`
	
	#virt_ibm_id; lt. CLIMA Shared Pool ID	
	VIRT_IBM_ID=`lparstat -i | grep "Shared Pool ID" | awk -F ":" '{ print$2 }'| tr -d ' '`
	
	#virt_ibm_core_count
	VIRT_IBM_CORE_COUNT=`lparstat -i | grep "Active CPUs in Pool" | awk -F ":" '{ print$2 }' | tr -d ' '`
	
	#virt_ibm_entitled_capacity
	VIRT_ENTITELD_CAPACITY=`lparstat -i | grep "Entitled Capacity        " | awk -F ":" '{ print$2 }' | tr -d ' '`
	
	#virt_ibm_virtual_core_count
	VIRT_CORE_COUNT=`lparstat -i | grep "Online Virtual CPUs" | awk -F ":" '{ print$2 }'| tr -d ' '`
	
	#virt_ibm_is_capped
	VIRT_CAP=`lparstat -i | grep "^Mode" | awk -F ":" '{ print$2 }'| tr -d ' ' | tr '[:upper:]' '[:lower:]'`
	
	#virt_ibm_lpm
	# wird nicht genutzt bei Datenbanken
	

	if [[ -n "$VIRTUALIZATION_TECHNOLOGY"   ]]
	then
		json_array_get_index_by_module "device_virtual"
		json_module_start_level "$MACHINE_UUID"
		json_module_key_value "virt_device_id" "$PHYSICAL_ID"
		json_module_key_value "virt_machine_uuid" "$MACHINE_UUID"
		json_module_key_value "virt_hostname" "$HOSTNAME"
		json_module_key_value "virt_virtualization_tech" "$VIRTUALIZATION_TECHNOLOGY"
		json_module_key_value "virt_is_active" "y"
		json_module_key_value "virt_script_version" "$SCRIPT_VERSION_AIX_DEVICE_VIRTUALIZATION"
		json_module_key_value "virt_script_last_update" "$DATE_TIME"
		json_module_key_value "virt_memory_mb" "$VIRT_MEMORY_MB"
		
		# IBM
		json_module_key_value "virt_ibm_id"  "$VIRT_IBM_ID"
		json_module_key_value "virt_ibm_core_count"  "$VIRT_IBM_CORE_COUNT"
		json_module_key_value "virt_ibm_entitled_capacity" "$VIRT_ENTITELD_CAPACITY"
		json_module_key_value "virt_ibm_virtual_core_count"  "$VIRT_CORE_COUNT"
		json_module_key_value "virt_ibm_is_capped"  "$VIRT_CAP"
		json_module_key_value "virt_ibm_lpm"   "not in use"
		
		json_module_end_level
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi