#########################################################################################################
#													#
#	Projekt:	Automatisierung Lizenzmanagement (ALM)						#
#	Skript:		device_virtualization_solaris.sh						#
#	Funktion:	Abfrage der Virtualisierung unter Solaris					#
#													#
#########################################################################################################
#													#
#	Versionshistorie:										#
#													#
#	2 (16.10.2017): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Korrektur: capped/uncapped und whole-core Konfiguartion bei LDOMs entfaellt.		#
#                       Das wird in der Control-Domain ausgelesen                                       #
#													#
#	1 (21.07.2015): Falko Boehme (NSO-DSID), falko.boehme@telekom.de				#
#		Erste Version										#
#													#
#########################################################################################################

# Kontrolle ob Skript nur gesourced wurde und nicht gestartet wurde
if [ -n "$IS_STARTED_FROM_COLLECTOR" ]
then
	SCRIPT_VERSION_SOLARIS_DEVICE_VIRTUALIZATION='2'
	
	if [ "$VIRTUALIZATION_TECHNOLOGY" = "Solaris LDOM" ]
	then
		# wenn es die PRIMARY ist meussen wir noch die physikalischen Daten mit erfassen
		LDM_LIST=`/usr/sbin/ldm list 2> /dev/null`
		if [ -n "$LDM_LIST" ]
		then
			# nur auf der Primary gibt das Kommando ldm einen Output
			PHYS_VIRTUALIZATION="Solaris LDOM"
			
			# CPU
			. ./solaris_device_cpu.sh
			
			# Physik
			. ./solaris_device_physical.sh
			
			LDOM_CORE_COUNT=`echo "$KSTAT_CPUINFO" | grep core_id | grep -v pkg_core_id | awk '{print $2}' | sort | uniq | wc -l | tr -d ' '`
			LDOM_THREAD_COUNT=`echo "$KSTAT_CPUINFO" | grep "module: cpu_info" | awk '{ print $4 }' | sort | uniq | wc -l | tr -d ' '`
		fi
		
		# Wenn es auch noch lokale Zonen gibt, haben wir doppelte Virtualisierung
		ZONE_LIST=`zoneadm list -p | grep -v global`
		if [ -n "$ZONE_LIST" ]
		then
			VIRT_LEVEL1="$VIRTUALIZATION_TECHNOLOGY"
			PHYS_VIRTUALIZATION="Solaris Zones"
			
			# Physik
			. ./solaris_device_phys_for_virt.sh			
		fi
	fi
	
	# Memory
	VIRT_MEMORY_MB=`prtconf 2>/dev/null | grep Memory | cut -d ':' -f2 | awk '{print $1}'`
	
	if [ -n "$VIRTUALIZATION_TECHNOLOGY" ]
	then
		json_array_get_index_by_module "device_virtual"
		json_module_start_level "$MACHINE_UUID"
		json_module_key_value "virt_device_id" "$PHYSICAL_ID"
		json_module_key_value "virt_machine_uuid" "$MACHINE_UUID"
		json_module_key_value "virt_hostname" "$HOSTNAME"
		json_module_key_value "virt_virtualization_tech" "$VIRTUALIZATION_TECHNOLOGY"
		json_module_key_value "virt_is_active" "y"
		json_module_key_value "virt_script_version" "$SCRIPT_VERSION_SOLARIS_DEVICE_VIRTUALIZATION"
		json_module_key_value "virt_script_last_update" "$DATE_TIME"
		json_module_key_value "virt_memory_mb" "$VIRT_MEMORY_MB"
		json_module_key_value "virt_responsible_group_name" "$RESPONSIBLE_GROUP_NAME"
		
		case "$VIRTUALIZATION_TECHNOLOGY" in
			'Solaris Zones')
				ZONE_ID=`zonename`
				json_module_key_value "virt_sun_lzone_id" "$ZONE_ID"
				json_module_key_value "virt_sun_lzone_core_count" "$CPU_CORE_COUNT"
				json_module_key_value "virt_sun_lzone_virtual_core_count" "$CPU_THREAD_COUNT"
				;;
			'Solaris LDOM')	
				json_module_key_value "virt_sun_ldom_id" "$HOSTNAME"
				json_module_key_value "virt_sun_ldom_core_count" "$LDOM_CORE_COUNT"
				json_module_key_value "virt_sun_ldom_virtual_core_count" "$LDOM_THREAD_COUNT"
				;;
		esac
		json_module_end_level
	fi
else
	echo "Script $0 must not be executed but sourced from alm_collector.sh"
fi