#!/usr/bin/env python
import uuid
print uuid.uuid4()